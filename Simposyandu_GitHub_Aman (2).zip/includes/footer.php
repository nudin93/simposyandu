</div><!-- /.content-wrapper -->
<footer class="main-footer text-center">
  <strong>Copyright &copy; <?= date('Y') ?> <a href="#"><?= $pengaturan['nama_posyandu'] ?? 'Posyandu' ?></a>.</strong>
</footer>
<aside class="control-sidebar control-sidebar-dark"></aside>
</div><!-- ./wrapper -->

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<!-- Bootstrap 5 Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE 3 -->
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/js/adminlte.min.js"></script>
<!-- Select2 -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<!-- Flatpickr -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.to/flatpickr/dist/l10n/id.js"></script>
<!-- DataTables -->
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/responsive.bootstrap5.min.js"></script>
<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- QRCode.js -->
<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>

<script>
function toggleMenu(el) {
  try {
    var item = el.parentElement;
    if (!item) return false;
    var submenu = item.querySelector('ul.nav-treeview');
    if (!submenu) return false;
    var isOpen = item.classList.contains('menu-open');
    document.querySelectorAll('.nav-sidebar > .nav-item.menu-open').forEach(function(other) {
      if (other !== item) {
        other.classList.remove('menu-open');
        var s = other.querySelector('ul.nav-treeview');
        if (s) s.style.display = 'none';
      }
    });
    if (isOpen) {
      item.classList.remove('menu-open');
      submenu.style.display = 'none';
    } else {
      item.classList.add('menu-open');
      submenu.style.display = 'block';
    }
  } catch (e) {}
  return false;
}
</script>
<!-- Custom JS -->
<script src="<?= APP_URL ?>/assets/js/custom.js"></script>
<?php if (isset($extra_js)) echo $extra_js; ?>
</body>
</html>
