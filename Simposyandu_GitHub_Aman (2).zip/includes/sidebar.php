<?php
$pengaturan = $pengaturan ?? getPengaturan();
$current = basename($_SERVER['PHP_SELF']);
$folder = basename(dirname($_SERVER['PHP_SELF']));

$openData     = in_array($folder, ['penduduk','keluarga']);
$openBumil    = in_array($folder, ['ibu_hamil','pemeriksaan_ibu_hamil']);
$openBayi     = in_array($folder, ['bayi','pemeriksaan_bayi']);
$openBalita   = in_array($folder, ['balita','pemeriksaan_balita','imunisasi','vitamin']);
$openRemaja   = in_array($folder, ['remaja','pemeriksaan_remaja']);
$openUP       = in_array($folder, ['usia_produktif','pemeriksaan_dewasa']);
$openLansia   = in_array($folder, ['lansia','pemeriksaan_lansia']);
$openKB       = ($folder === 'kb');
$openKegiatan = in_array($folder, ['kegiatan_posyandu','kunjungan_rumah','jadwal']);
$openSanitasi = in_array($folder, ['sanitasi','phbs']);
$openLaporan  = ($folder === 'laporan');
$openStat     = ($folder === 'statistik');

$opensidOk = function_exists('opensid_available') ? opensid_available() : false;
$appName = htmlspecialchars($pengaturan['nama_aplikasi'] ?? 'SIMPOSYANDU');
$u = function_exists('currentUser') ? currentUser() : [];
$isKD = function_exists('isKepalaDesa') && isKepalaDesa();
$canIn = function_exists('canInput') ? canInput() : true;
$canMg = function_exists('canManage') ? canManage() : (function_exists('isAdmin') && isAdmin());

function navActive($cond) { return $cond ? 'active' : ''; }
function menuOpen($cond) { return $cond ? 'menu-open' : ''; }
?>
<aside class="main-sidebar sidebar-light-primary elevation-1 opensid-sidebar">
  <a href="<?= APP_URL ?>/dashboard.php" class="brand-link">
    <img src="<?= APP_URL ?>/assets/img/logo.png" alt="Logo" class="brand-image img-circle elevation-1" onerror="this.src='<?= APP_URL ?>/assets/img/favicon.ico'">
    <span class="brand-text font-weight-bold"><?= $appName ?></span>
  </a>

  <div class="sidebar">
    <div class="user-panel d-flex align-items-center px-3 py-2">
      <div class="image">
        <img src="<?= !empty($u['foto']) ? APP_URL.'/uploads/kader/'.$u['foto'] : APP_URL.'/assets/img/user.png' ?>" class="img-circle elevation-1" alt="User" style="width:34px;height:34px;object-fit:cover;" onerror="this.src='<?= APP_URL ?>/assets/img/favicon.ico'">
      </div>
      <div class="info flex-grow-1 ms-2">
        <a href="<?= APP_URL ?>/modules/kader/profile.php" class="d-block text-dark fw-semibold" style="font-size:0.88rem;line-height:1.2;">
          <?= htmlspecialchars($u['nama'] ?? 'Pengguna') ?>
        </a>
        <small class="text-muted"><?= htmlspecialchars(ucfirst($u['role'] ?? 'kader')) ?></small>
      </div>
    </div>

    <nav class="mt-1">
      <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu">

        <!-- UTAMA -->
        <li class="nav-header">UTAMA</li>
        <li class="nav-item">
          <a href="<?= APP_URL ?>/dashboard.php" class="nav-link <?= navActive($current==='dashboard.php') ?>">
            <i class="nav-icon fas fa-home"></i>
            <p>Beranda</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="<?= APP_URL ?>/modules/statistik/index.php" class="nav-link <?= navActive($openStat) ?>">
            <i class="nav-icon fas fa-chart-pie"></i>
            <p>Statistik</p>
          </a>
        </li>

        <!-- DATA WARGA (OpenSID) -->
        <li class="nav-header">DATA WARGA</li>
        <li class="nav-item <?= menuOpen($openData) ?>">
          <a href="#" class="nav-link <?= navActive($openData) ?>" onclick="return toggleMenu(this)">
            <i class="nav-icon fas fa-users"></i>
            <p>Kependudukan <i class="right fas fa-angle-left"></i></p>
          </a>
          <ul class="nav nav-treeview" style="<?= $openData ? 'display:block' : 'display:none' ?>">
            <li class="nav-item">
              <a href="<?= APP_URL ?>/modules/penduduk/index.php" class="nav-link <?= navActive($folder==='penduduk') ?>">
                <i class="nav-icon far fa-circle"></i>
                <p>Penduduk</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= APP_URL ?>/modules/keluarga/index.php" class="nav-link <?= navActive($folder==='keluarga') ?>">
                <i class="nav-icon far fa-circle"></i>
                <p>Keluarga</p>
              </a>
            </li>
          </ul>
        </li>

        <!-- SIKLUS HIDUP ILP -->
        <li class="nav-header">SIKLUS HIDUP (ILP)</li>

        <li class="nav-item <?= menuOpen($openBumil) ?>">
          <a href="#" class="nav-link <?= navActive($openBumil) ?>" onclick="return toggleMenu(this)">
            <i class="nav-icon fas fa-female"></i>
            <p>Ibu Hamil <i class="right fas fa-angle-left"></i></p>
          </a>
          <ul class="nav nav-treeview" style="<?= $openBumil ? 'display:block' : 'display:none' ?>">
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/ibu_hamil/index.php" class="nav-link <?= navActive($folder==='ibu_hamil') ?>"><i class="nav-icon far fa-circle"></i><p>Data Ibu Hamil</p></a></li>
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/pemeriksaan_ibu_hamil/index.php" class="nav-link <?= navActive($folder==='pemeriksaan_ibu_hamil') ?>"><i class="nav-icon far fa-circle"></i><p>Pemeriksaan ANC</p></a></li>
          </ul>
        </li>

        <li class="nav-item <?= menuOpen($openBayi) ?>">
          <a href="#" class="nav-link <?= navActive($openBayi) ?>" onclick="return toggleMenu(this)">
            <i class="nav-icon fas fa-baby"></i>
            <p>Bayi (0–12 bln) <i class="right fas fa-angle-left"></i></p>
          </a>
          <ul class="nav nav-treeview" style="<?= $openBayi ? 'display:block' : 'display:none' ?>">
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/bayi/index.php" class="nav-link <?= navActive($folder==='bayi') ?>"><i class="nav-icon far fa-circle"></i><p>Data Bayi</p></a></li>
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/pemeriksaan_bayi/index.php" class="nav-link <?= navActive($folder==='pemeriksaan_bayi') ?>"><i class="nav-icon far fa-circle"></i><p>Pemeriksaan Bayi</p></a></li>
          </ul>
        </li>

        <li class="nav-item <?= menuOpen($openBalita) ?>">
          <a href="#" class="nav-link <?= navActive($openBalita) ?>" onclick="return toggleMenu(this)">
            <i class="nav-icon fas fa-child"></i>
            <p>Balita <i class="right fas fa-angle-left"></i></p>
          </a>
          <ul class="nav nav-treeview" style="<?= $openBalita ? 'display:block' : 'display:none' ?>">
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/balita/index.php" class="nav-link <?= navActive($folder==='balita') ?>"><i class="nav-icon far fa-circle"></i><p>Data Balita</p></a></li>
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/pemeriksaan_balita/index.php" class="nav-link <?= navActive($folder==='pemeriksaan_balita') ?>"><i class="nav-icon far fa-circle"></i><p>Pemeriksaan Gizi</p></a></li>
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/imunisasi/index.php" class="nav-link <?= navActive($folder==='imunisasi') ?>"><i class="nav-icon far fa-circle"></i><p>Imunisasi</p></a></li>
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/vitamin/index.php" class="nav-link <?= navActive($folder==='vitamin') ?>"><i class="nav-icon far fa-circle"></i><p>Vitamin A</p></a></li>
          </ul>
        </li>

        <li class="nav-item <?= menuOpen($openRemaja) ?>">
          <a href="#" class="nav-link <?= navActive($openRemaja) ?>" onclick="return toggleMenu(this)">
            <i class="nav-icon fas fa-user-graduate"></i>
            <p>Anak Sekolah & Remaja <i class="right fas fa-angle-left"></i></p>
          </a>
          <ul class="nav nav-treeview" style="<?= $openRemaja ? 'display:block' : 'display:none' ?>">
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/remaja/index.php" class="nav-link <?= navActive($folder==='remaja') ?>"><i class="nav-icon far fa-circle"></i><p>Data Remaja</p></a></li>
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/pemeriksaan_remaja/index.php" class="nav-link <?= navActive($folder==='pemeriksaan_remaja') ?>"><i class="nav-icon far fa-circle"></i><p>Pemeriksaan</p></a></li>
          </ul>
        </li>

        <li class="nav-item <?= menuOpen($openUP) ?>">
          <a href="#" class="nav-link <?= navActive($openUP) ?>" onclick="return toggleMenu(this)">
            <i class="nav-icon fas fa-user-tie"></i>
            <p>Usia Produktif <i class="right fas fa-angle-left"></i></p>
          </a>
          <ul class="nav nav-treeview" style="<?= $openUP ? 'display:block' : 'display:none' ?>">
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/usia_produktif/index.php" class="nav-link <?= navActive($folder==='usia_produktif') ?>"><i class="nav-icon far fa-circle"></i><p>Data Usia Produktif</p></a></li>
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/pemeriksaan_dewasa/index.php" class="nav-link <?= navActive($folder==='pemeriksaan_dewasa') ?>"><i class="nav-icon far fa-circle"></i><p>Skrining PTM</p></a></li>
          </ul>
        </li>

        <li class="nav-item <?= menuOpen($openLansia) ?>">
          <a href="#" class="nav-link <?= navActive($openLansia) ?>" onclick="return toggleMenu(this)">
            <i class="nav-icon fas fa-blind"></i>
            <p>Lansia <i class="right fas fa-angle-left"></i></p>
          </a>
          <ul class="nav nav-treeview" style="<?= $openLansia ? 'display:block' : 'display:none' ?>">
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/lansia/index.php" class="nav-link <?= navActive($folder==='lansia') ?>"><i class="nav-icon far fa-circle"></i><p>Data Lansia</p></a></li>
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/pemeriksaan_lansia/index.php" class="nav-link <?= navActive($folder==='pemeriksaan_lansia') ?>"><i class="nav-icon far fa-circle"></i><p>Pemeriksaan Lansia</p></a></li>
          </ul>
        </li>

        <li class="nav-item">
          <a href="<?= APP_URL ?>/modules/kb/index.php" class="nav-link <?= navActive($openKB) ?>">
            <i class="nav-icon fas fa-pills"></i>
            <p>Keluarga Berencana</p>
          </a>
        </li>

        <!-- KEGIATAN -->
        <li class="nav-header">KEGIATAN POSYANDU</li>
        <li class="nav-item <?= menuOpen($openKegiatan) ?>">
          <a href="#" class="nav-link <?= navActive($openKegiatan) ?>" onclick="return toggleMenu(this)">
            <i class="nav-icon fas fa-calendar-check"></i>
            <p>Kegiatan <i class="right fas fa-angle-left"></i></p>
          </a>
          <ul class="nav nav-treeview" style="<?= $openKegiatan ? 'display:block' : 'display:none' ?>">
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/kegiatan_posyandu/index.php" class="nav-link <?= navActive($folder==='kegiatan_posyandu') ?>"><i class="nav-icon far fa-circle"></i><p>Kegiatan Posyandu</p></a></li>
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/kunjungan_rumah/index.php" class="nav-link <?= navActive($folder==='kunjungan_rumah') ?>"><i class="nav-icon far fa-circle"></i><p>Kunjungan Rumah</p></a></li>
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/jadwal/index.php" class="nav-link <?= navActive($folder==='jadwal') ?>"><i class="nav-icon far fa-circle"></i><p>Jadwal Posyandu</p></a></li>
          </ul>
        </li>

        <!-- LINGKUNGAN -->
        <li class="nav-header">KESEHATAN LINGKUNGAN</li>
        <li class="nav-item <?= menuOpen($openSanitasi) ?>">
          <a href="#" class="nav-link <?= navActive($openSanitasi) ?>" onclick="return toggleMenu(this)">
            <i class="nav-icon fas fa-hand-holding-water"></i>
            <p>Sanitasi & PHBS <i class="right fas fa-angle-left"></i></p>
          </a>
          <ul class="nav nav-treeview" style="<?= $openSanitasi ? 'display:block' : 'display:none' ?>">
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/sanitasi/index.php" class="nav-link <?= navActive($folder==='sanitasi') ?>"><i class="nav-icon far fa-circle"></i><p>Sanitasi</p></a></li>
            <li class="nav-item"><a href="<?= APP_URL ?>/modules/phbs/index.php" class="nav-link <?= navActive($folder==='phbs') ?>"><i class="nav-icon far fa-circle"></i><p>PHBS</p></a></li>
          </ul>
        </li>

        <!-- LAPORAN -->
        <li class="nav-header">LAPORAN</li>
        <li class="nav-item">
          <a href="<?= APP_URL ?>/modules/laporan/index.php" class="nav-link <?= navActive($openLaporan) ?>">
            <i class="nav-icon fas fa-file-alt"></i>
            <p>Laporan ILP</p>
          </a>
        </li>
        <?php if (!$isKD): ?>
        <li class="nav-item">
          <a href="<?= APP_URL ?>/modules/kartu/index.php" class="nav-link <?= navActive($folder==='kartu') ?>">
            <i class="nav-icon fas fa-id-card"></i>
            <p>Cetak Kartu</p>
          </a>
        </li>
        <?php endif; ?>

        <!-- PENGATURAN -->
        <?php if ($canMg): ?>
        <li class="nav-header">PENGATURAN</li>
        <li class="nav-item">
          <a href="<?= APP_URL ?>/modules/kader/index.php" class="nav-link <?= navActive($folder==='kader') ?>">
            <i class="nav-icon fas fa-user-shield"></i>
            <p>Pengguna / Kader</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="<?= APP_URL ?>/modules/backup/index.php" class="nav-link <?= navActive($folder==='backup') ?>">
            <i class="nav-icon fas fa-database"></i>
            <p>Backup Database</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="<?= APP_URL ?>/modules/pengaturan/index.php" class="nav-link <?= navActive($folder==='pengaturan') ?>">
            <i class="nav-icon fas fa-cog"></i>
            <p>Pengaturan Aplikasi</p>
          </a>
        </li>
        <?php endif; ?>

        <li class="nav-header">STATUS</li>
        <li class="nav-item">
          <span class="nav-link" style="cursor:default;">
            <?php if ($opensidOk): ?>
            <i class="nav-icon fas fa-link text-success"></i>
            <p class="text-success" style="font-size:0.8rem;">OpenSID terhubung</p>
            <?php else: ?>
            <i class="nav-icon fas fa-unlink text-danger"></i>
            <p class="text-danger" style="font-size:0.8rem;">OpenSID terputus</p>
            <?php endif; ?>
          </span>
        </li>
        <li class="nav-item">
          <a href="<?= APP_URL ?>/logout.php" class="nav-link">
            <i class="nav-icon fas fa-sign-out-alt"></i>
            <p>Keluar</p>
          </a>
        </li>

        <li class="nav-item sidebar-bottom-spacer" aria-hidden="true" style="height:80px;pointer-events:none;"></li>
      </ul>
    </nav>
  </div>
</aside>
