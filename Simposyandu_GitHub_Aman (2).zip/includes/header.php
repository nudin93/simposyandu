<?php
require_once __DIR__ . '/../config/init.php';
requireLogin();
$pengaturan = getPengaturan();
$user = currentUser();
$app_name = $pengaturan['nama_aplikasi'] ?? 'SIMPOSYANDU';
$posyandu = $pengaturan['nama_posyandu'] ?? 'Posyandu';
$warna = $pengaturan['warna_tema'] ?? 'blue';
$dark = $pengaturan['dark_mode'] ? 'dark-mode' : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= $page_title ?? $app_name ?> | <?= $app_name ?></title>
  <link rel="icon" type="image/x-icon" href="<?= APP_URL ?>/assets/img/favicon.ico">
  <!-- Google Font (Source Sans Pro = OpenSID style + Inter fallback) -->
  <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@300;400;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <!-- Bootstrap 5 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <!-- AdminLTE 3 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/css/adminlte.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css">
  <!-- Flatpickr -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/custom.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed text-sm <?= $dark ?>">
<div class="wrapper">

<!-- Navbar - OpenSID style (solid blue) -->
<nav class="main-header navbar navbar-expand navbar-dark opensid-navbar">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </li>
  </ul>
  <ul class="navbar-nav mx-auto">
    <li class="nav-item">
      <a href="<?= APP_URL ?>/dashboard.php" class="nav-link opensid-brand"><?= $app_name ?></a>
    </li>
  </ul>
  <ul class="navbar-nav">
    <li class="nav-item dropdown user-menu">
      <a href="#" class="nav-link" data-bs-toggle="dropdown">
        <img src="<?= $user['foto'] ? APP_URL.'/uploads/kader/'.$user['foto'] : APP_URL.'/assets/img/user.png' ?>" class="user-image img-circle elevation-1" alt="User" style="width:28px;height:28px;object-fit:cover;">
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <li class="user-header bg-primary">
          <img src="<?= $user['foto'] ? APP_URL.'/uploads/kader/'.$user['foto'] : APP_URL.'/assets/img/user.png' ?>" class="img-circle elevation-2">
          <p><?= htmlspecialchars($user['nama']) ?> <small><?= ucfirst($user['role']) ?></small></p>
        </li>
        <li class="user-footer">
          <a href="<?= APP_URL ?>/modules/kader/profile.php" class="btn btn-default btn-flat">Profil</a>
          <a href="<?= APP_URL ?>/logout.php" class="btn btn-default btn-flat float-end">Keluar</a>
        </li>
      </ul>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?= APP_URL ?>/modules/pengaturan/index.php" title="Pengaturan"><i class="fas fa-cog"></i></a>
    </li>
  </ul>
</nav>

<?php include __DIR__ . '/sidebar.php'; ?>
<div class="content-wrapper">
