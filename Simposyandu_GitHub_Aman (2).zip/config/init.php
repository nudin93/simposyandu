<?php
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/session.php';
