<?php
// Contoh konfigurasi database
// Salin menjadi database.php saat instalasi

$db_host = "localhost";
$db_user = "username_database";
$db_pass = "password_database";
$db_name = "nama_database";
?>
