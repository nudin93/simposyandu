<?php
$page_title='Skrining PTM'; require_once __DIR__.'/../../includes/header.php';
$id=(int)($_GET['id']??0); $u=$id?fetchOne("SELECT * FROM usia_produktif WHERE id=$id"):null;
if(!$u){echo '<div class="alert alert-warning m-3">Pilih data usia produktif dulu.</div>';include __DIR__.'/../../includes/footer.php';exit;}
?>
<section class="content"><div class="container-fluid"><div class="card"><div class="card-header">Skrining: <?=htmlspecialchars($u['nama_lengkap'])?></div><div class="card-body">
<form id="f" action="<?= APP_URL ?>/ajax/save_pemeriksaan_dewasa.php" method="post">
<input type="hidden" name="usia_produktif_id" value="<?=$id?>">
<div class="row g-3">
<div class="col-md-3"><label>Tanggal</label><input type="date" name="tanggal_pemeriksaan" class="form-control" value="<?=date('Y-m-d')?>" required></div>
<div class="col-md-3"><label>BB (kg)</label><input type="number" step="0.1" name="berat_badan" id="bb" class="form-control"></div>
<div class="col-md-3"><label>TB (cm)</label><input type="number" step="0.1" name="tinggi_badan" id="tb" class="form-control"></div>
<div class="col-md-3"><label>IMT</label><input name="imt" id="imt" class="form-control" readonly></div>
<div class="col-md-3"><label>Lingkar Perut (cm)</label><input type="number" step="0.1" name="lingkar_perut" class="form-control"></div>
<div class="col-md-3"><label>Tekanan Darah</label><input name="tekanan_darah" class="form-control" placeholder="120/80"></div>
<div class="col-md-3"><label>Gula Darah</label><input type="number" step="0.1" name="gula_darah" class="form-control"></div>
<div class="col-md-3"><label>Kolesterol</label><input type="number" step="0.1" name="kolesterol" class="form-control"></div>
<div class="col-md-12"><label>Faktor Risiko / Keluhan</label><textarea name="faktor_risiko" class="form-control" rows="2"></textarea></div>
<div class="col-md-6"><label>Penanganan</label><textarea name="penanganan" class="form-control" rows="2"></textarea></div>
<div class="col-md-6"><label>Rujukan</label><textarea name="rujukan" class="form-control" rows="2"></textarea></div>
</div>
<button class="btn btn-primary mt-3">Simpan</button>
</form></div></div></div></section>
<script>
bb.oninput=tb.oninput=()=>{const b=+bb.value,t=+tb.value;imt.value=(b&&t)?(b/((t/100)**2)).toFixed(2):'';};
f.onsubmit=e=>{e.preventDefault();ajaxSubmitForm(f,{redirect:'../usia_produktif/index.php'});};
</script>
<?php include __DIR__.'/../../includes/footer.php'; ?>
