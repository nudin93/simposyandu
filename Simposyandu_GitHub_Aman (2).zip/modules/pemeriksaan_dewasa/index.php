<?php
$page_title='Skrining PTM / Usia Produktif'; require_once __DIR__.'/../../includes/header.php';
$data=[]; try{$data=fetchAll("SELECT pd.*, u.nama_lengkap FROM pemeriksaan_dewasa pd JOIN usia_produktif u ON u.id=pd.usia_produktif_id ORDER BY pd.tanggal_pemeriksaan DESC LIMIT 500");}catch(Throwable $e){}
$canDel = function_exists('canInput') ? canInput() : true;
?>
<section class="content-header"><div class="container-fluid"><h1>Skrining PTM</h1></div></section>
<section class="content"><div class="container-fluid"><div class="card"><div class="card-body table-responsive">
<table class="table table-hover datatable" style="width:100%">
<thead><tr><th>No</th><th>Tanggal</th><th>Nama</th><th>BB</th><th>TB</th><th>IMT</th><th>LP</th><th>TD</th><th>Gula</th><th>Risiko</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach($data as $i=>$r):
  $risk=[]; if($r['risiko_hipertensi'])$risk[]='HT'; if($r['risiko_diabetes'])$risk[]='DM'; if($r['risiko_obesitas'])$risk[]='Obesitas';
?>
<tr>
<td><?=$i+1?></td>
<td><?=formatTanggal($r['tanggal_pemeriksaan'])?></td>
<td><?=htmlspecialchars($r['nama_lengkap'])?></td>
<td><?=$r['berat_badan']?></td>
<td><?=$r['tinggi_badan']?></td>
<td><?=$r['imt']?></td>
<td><?=$r['lingkar_perut']?></td>
<td><?=$r['tekanan_darah']?></td>
<td><?=$r['gula_darah']?></td>
<td><?=$risk?implode(', ',$risk):'Normal'?></td>
<td>
<?php if($canDel):?>
<button type="button" class="btn btn-sm btn-danger" onclick="confirmDelete('<?= APP_URL ?>/ajax/delete.php?type=pemeriksaan_dewasa&id=<?= (int)$r['id'] ?>','Skrining <?= htmlspecialchars($r['nama_lengkap'], ENT_QUOTES) ?>')" title="Hapus"><i class="fas fa-trash"></i></button>
<?php endif;?>
</td>
</tr>
<?php endforeach;?>
</tbody></table>
</div></div></div></section>
<?php include __DIR__.'/../../includes/footer.php'; ?>
