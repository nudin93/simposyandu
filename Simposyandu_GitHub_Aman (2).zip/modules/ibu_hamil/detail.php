<?php
$page_title = 'Detail Data';
require_once __DIR__ . '/../../includes/header.php';
$id = (int)($_GET['id'] ?? 0);
?>
<section class="content-header"><div class="container-fluid"><div class="row mb-2">
  <div class="col-sm-6"><h1><i class="fas fa-info-circle me-2"></i>Detail Data</h1></div>
  <div class="col-sm-6"><ol class="breadcrumb float-sm-end"><li class="breadcrumb-item"><a href="../../dashboard.php">Dashboard</a></li><li class="breadcrumb-item"><a href="index.php">Kembali</a></li><li class="breadcrumb-item active">Detail</li></ol></div>
</div></div></section>
<section class="content"><div class="container-fluid">
<div class="card"><div class="card-body text-center py-5">
  <i class="fas fa-info-circle fa-3x text-muted mb-3 d-block"></i>
  <h5 class="text-muted">Halaman detail dalam pengembangan</h5>
  <a href="index.php" class="btn btn-secondary mt-3"><i class="fas fa-arrow-left me-2"></i>Kembali</a>
</div></div>
</div></section>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
