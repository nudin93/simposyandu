<?php
$page_title = 'Data Ibu Hamil';
require_once __DIR__ . '/../../includes/header.php';
$data = fetchAll("SELECT *, TIMESTAMPDIFF(WEEK, hpht, CURDATE()) as usia_minggu FROM ibu_hamil ORDER BY created_at DESC");
?>
<section class="content-header"><div class="container-fluid"><div class="row mb-2">
  <div class="col-sm-6"><h1><i class="fas fa-female me-2 text-danger"></i>Data Ibu Hamil</h1></div>
  <div class="col-sm-6"><ol class="breadcrumb float-sm-end"><li class="breadcrumb-item"><a href="../../dashboard.php">Dashboard</a></li><li class="breadcrumb-item active">Ibu Hamil</li></ol></div>
</div></div></section>
<section class="content"><div class="container-fluid">
<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h5 class="mb-0"><i class="fas fa-list me-2"></i>Daftar Ibu Hamil</h5>
    <div class="d-flex gap-2">
      <a href="tambah.php" class="btn btn-danger"><i class="fas fa-plus me-1"></i>Tambah Ibu Hamil</a>
    </div>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-hover datatable">
        <thead><tr><th>No</th><th>No. Peserta</th><th>Nama Ibu</th><th>HPHT</th><th>HPL</th><th>Usia Kandungan</th><th>Kehamilan Ke-</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($data as $i => $ibu): ?>
        <?php $last_pmx = fetchOne("SELECT status_risiko FROM pemeriksaan_ibu_hamil WHERE ibu_hamil_id={$ibu['id']} ORDER BY tanggal_pemeriksaan DESC LIMIT 1"); ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><span class="badge bg-danger"><?= $ibu['nomor_peserta'] ?></span></td>
          <td>
            <div class="fw-semibold"><?= htmlspecialchars($ibu['nama']) ?></div>
            <small class="text-muted"><?= $ibu['no_hp']??'' ?></small>
          </td>
          <td><?= formatTanggal($ibu['hpht']) ?></td>
          <td><?= formatTanggal($ibu['hpl']) ?></td>
          <td><?= $ibu['usia_minggu'] ? $ibu['usia_minggu'] . ' minggu' : '-' ?></td>
          <td>Ke-<?= $ibu['kehamilan_ke'] ?></td>
          <td>
            <?php if ($last_pmx): ?>
            <span class="badge bg-<?= $last_pmx['status_risiko']=='Normal'?'success':($last_pmx['status_risiko']=='Risiko Ringan'?'warning':'danger') ?>"><?= $last_pmx['status_risiko'] ?></span>
            <?php else: ?><span class="badge bg-secondary">Belum Periksa</span><?php endif; ?>
          </td>
          <td>
            <a href="detail.php?id=<?= $ibu['id'] ?>" class="btn btn-sm btn-info"><i class="fas fa-eye"></i></a>
            <a href="edit.php?id=<?= $ibu['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
            <a href="../pemeriksaan_ibu_hamil/tambah.php?ibu_hamil_id=<?= $ibu['id'] ?>" class="btn btn-sm btn-success" title="Periksa"><i class="fas fa-stethoscope"></i></a>
            <a href="../kartu/cetak.php?type=ibu_hamil&id=<?= $ibu['id'] ?>" class="btn btn-sm btn-secondary" target="_blank"><i class="fas fa-id-card"></i></a>
            <button type="button" class="btn btn-sm btn-danger" onclick="confirmDelete('<?= APP_URL ?>/ajax/delete.php?type=ibu_hamil&id=<?= $ibu['id'] ?>','<?= htmlspecialchars($ibu['nama'], ENT_QUOTES) ?>')" title="Hapus"><i class="fas fa-trash"></i></button>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div></section>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
