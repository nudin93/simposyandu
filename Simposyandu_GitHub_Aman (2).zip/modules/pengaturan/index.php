<?php
$page_title = 'Pengaturan Aplikasi';
require_once __DIR__ . '/../../includes/header.php';
if (!isAdmin()) { echo '<script>window.location="../../dashboard.php";</script>'; exit; }
$set = getPengaturan();
?>
<section class="content-header"><div class="container-fluid"><div class="row mb-2">
  <div class="col-sm-6"><h1><i class="fas fa-cog me-2 text-primary"></i>Pengaturan Aplikasi</h1></div>
  <div class="col-sm-6"><ol class="breadcrumb float-sm-end"><li class="breadcrumb-item"><a href="../../dashboard.php">Dashboard</a></li><li class="breadcrumb-item active">Pengaturan</li></ol></div>
</div></div></section>
<section class="content"><div class="container-fluid">
<div class="card">
  <div class="card-header bg-primary text-white"><h5 class="mb-0"><i class="fas fa-cog me-2"></i>Pengaturan Sistem</h5></div>
  <div class="card-body">
    <form method="POST" action="../../ajax/save_pengaturan.php" enctype="multipart/form-data" id="formPengaturan">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
    <div class="row g-4">
      <div class="col-12"><h6 class="fw-bold text-primary border-bottom pb-2"><i class="fas fa-info-circle me-2"></i>Informasi Posyandu</h6></div>
      <div class="col-md-6"><label class="form-label fw-semibold">Nama Aplikasi</label><input type="text" name="nama_aplikasi" class="form-control" value="<?= htmlspecialchars($set['nama_aplikasi']??'') ?>"></div>
      <div class="col-md-6"><label class="form-label fw-semibold">Nama Posyandu</label><input type="text" name="nama_posyandu" class="form-control" value="<?= htmlspecialchars($set['nama_posyandu']??'') ?>"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Nama Desa</label><input type="text" name="nama_desa" class="form-control" value="<?= htmlspecialchars($set['nama_desa']??'') ?>"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Kecamatan</label><input type="text" name="kecamatan" class="form-control" value="<?= htmlspecialchars($set['kecamatan']??'') ?>"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Kabupaten</label><input type="text" name="kabupaten" class="form-control" value="<?= htmlspecialchars($set['kabupaten']??'') ?>"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Provinsi</label><input type="text" name="provinsi" class="form-control" value="<?= htmlspecialchars($set['provinsi']??'') ?>"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">No. Kontak</label><input type="text" name="nomor_kontak" class="form-control" value="<?= htmlspecialchars($set['nomor_kontak']??'') ?>"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Email</label><input type="email" name="email" class="form-control" value="<?= htmlspecialchars($set['email']??'') ?>"></div>
      <div class="col-12"><h6 class="fw-bold text-primary border-bottom pb-2 mt-2"><i class="fas fa-palette me-2"></i>Tampilan</h6></div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Warna Tema</label>
        <select name="warna_tema" class="form-select select2">
          <?php foreach(['blue','green','red','purple','orange','teal','indigo','cyan','pink'] as $w): ?>
          <option value="<?= $w ?>" <?= ($set['warna_tema']??'blue')==$w?'selected':'' ?>><?= ucfirst($w) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Dark Mode Default</label>
        <div class="form-check form-switch mt-2"><input class="form-check-input" type="checkbox" name="dark_mode" id="darkMode" value="1" <?= ($set['dark_mode']??0)?'checked':'' ?>><label class="form-check-label" for="darkMode">Aktifkan Dark Mode</label></div>
      </div>
      <div class="col-12"><h6 class="fw-bold text-primary border-bottom pb-2 mt-2"><i class="fas fa-image me-2"></i>Logo & Favicon</h6></div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Logo Aplikasi</label>
        <?php if ($set['logo']): ?><div class="mb-2"><img src="<?= APP_URL ?>/uploads/settings/<?= $set['logo'] ?>" style="max-height:60px"></div><?php endif; ?>
        <input type="file" name="logo" class="form-control" accept=".jpg,.jpeg,.png,.svg">
        <small class="text-muted">JPG, PNG, SVG (Max 2MB)</small>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Favicon</label>
        <input type="file" name="favicon" class="form-control" accept=".ico,.png">
        <small class="text-muted">ICO, PNG</small>
      </div>
    </div>
    <div class="mt-4 d-flex justify-content-end"><button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-save me-2"></i>Simpan Pengaturan</button></div>
    </form>
  </div>
</div>
</div></section>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
<script>
(function() {
  var form = document.getElementById('formPengaturan');
  if (!form) return;
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    if (typeof showLoading === 'function') showLoading('Menyimpan pengaturan...');
    var fd = new FormData(form);
    fetch(form.action, { method: 'POST', body: fd })
      .then(function(res) { return res.json(); })
      .then(function(r) {
        if (typeof hideLoading === 'function') hideLoading();
        if (r && r.success) {
          if (typeof Swal !== 'undefined') {
            Swal.fire({ icon: 'success', title: 'Berhasil!', text: r.message || 'Pengaturan tersimpan', timer: 2000, showConfirmButton: false, heightAuto: false })
              .then(function() { location.reload(); });
          } else {
            alert(r.message || 'Pengaturan tersimpan');
            location.reload();
          }
        } else {
          var msg = (r && r.message) ? r.message : 'Gagal menyimpan';
          if (typeof Swal !== 'undefined') Swal.fire('Gagal!', msg, 'error');
          else alert(msg);
        }
      })
      .catch(function() {
        if (typeof hideLoading === 'function') hideLoading();
        if (typeof Swal !== 'undefined') Swal.fire('Error!', 'Koneksi bermasalah', 'error');
        else alert('Koneksi bermasalah');
      });
  });
})();
</script>
