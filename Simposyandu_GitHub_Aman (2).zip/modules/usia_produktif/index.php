<?php
$page_title='Usia Produktif'; require_once __DIR__.'/../../includes/header.php';
$data=[]; try{$data=fetchAll("SELECT *, TIMESTAMPDIFF(YEAR,tanggal_lahir,CURDATE()) as umur FROM usia_produktif WHERE status_aktif=1 ORDER BY created_at DESC");}catch(Throwable $e){}
$canDel = function_exists('canInput') ? canInput() : true;
?>
<section class="content-header"><div class="container-fluid"><h1><i class="fas fa-user-tie me-2 text-primary"></i>Usia Produktif</h1></div></section>
<section class="content"><div class="container-fluid"><div class="card">
<div class="card-header d-flex justify-content-between"><h5 class="mb-0">Daftar</h5>
<?php if($canDel):?><a href="tambah.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah</a><?php endif;?>
</div>
<div class="card-body table-responsive">
<table class="table table-hover datatable" style="width:100%">
<thead><tr><th>No</th><th>No.Peserta</th><th>Nama</th><th>JK</th><th>Umur</th><th>Dusun</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach($data as $i=>$r):?>
<tr>
<td><?=$i+1?></td>
<td><span class="badge bg-primary"><?=htmlspecialchars($r['nomor_peserta'])?></span></td>
<td><?=htmlspecialchars($r['nama_lengkap'])?></td>
<td><?=$r['jenis_kelamin']?></td>
<td><?=$r['umur']?> th</td>
<td><?=htmlspecialchars($r['dusun']??'-')?></td>
<td class="text-nowrap">
<a href="../pemeriksaan_dewasa/tambah.php?id=<?=$r['id']?>" class="btn btn-sm btn-success" title="Skrining"><i class="fas fa-stethoscope"></i></a>
<?php if($canDel):?>
<button type="button" class="btn btn-sm btn-danger" onclick="confirmDelete('<?= APP_URL ?>/ajax/delete.php?type=usia_produktif&id=<?= (int)$r['id'] ?>','<?= htmlspecialchars($r['nama_lengkap'], ENT_QUOTES) ?>')" title="Hapus"><i class="fas fa-trash"></i></button>
<?php endif;?>
</td>
</tr>
<?php endforeach;?>
</tbody></table>
</div></div></div></section>
<?php include __DIR__.'/../../includes/footer.php'; ?>
