<?php
$page_title = 'Profil Saya';
require_once __DIR__ . '/../../includes/header.php';
$my_data = fetchOne("SELECT * FROM kader WHERE id=" . (int)$user['id']);
?>
<section class="content-header"><div class="container-fluid"><div class="row mb-2">
  <div class="col-sm-6"><h1><i class="fas fa-user-circle me-2"></i>Profil Saya</h1></div>
  <div class="col-sm-6"><ol class="breadcrumb float-sm-end"><li class="breadcrumb-item"><a href="../../dashboard.php">Dashboard</a></li><li class="breadcrumb-item active">Profil</li></ol></div>
</div></div></section>
<section class="content"><div class="container-fluid">
<div class="row">
  <div class="col-md-4">
    <div class="card card-primary card-outline">
      <div class="card-body box-profile">
        <div class="text-center">
          <img class="profile-user-img img-fluid img-circle" style="width:100px;height:100px;object-fit:cover"
            src="<?= $my_data['foto'] ? APP_URL.'/uploads/kader/'.$my_data['foto'] : APP_URL.'/assets/img/user.png' ?>" alt="Foto Profil">
        </div>
        <h3 class="profile-username text-center"><?= htmlspecialchars($my_data['nama']) ?></h3>
        <p class="text-muted text-center"><?= $my_data['jabatan'] ?></p>
        <ul class="list-group list-group-unbordered mb-3">
          <li class="list-group-item"><b>Username</b><span class="float-end"><?= $my_data['username'] ?></span></li>
          <li class="list-group-item"><b>Role</b><span class="float-end"><?= ucfirst($my_data['role']) ?></span></li>
          <li class="list-group-item"><b>NIK</b><span class="float-end"><?= $my_data['nik']??'-' ?></span></li>
          <li class="list-group-item"><b>No. HP</b><span class="float-end"><?= $my_data['no_hp']??'-' ?></span></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="col-md-8">
    <div class="card">
      <div class="card-header"><h5 class="mb-0"><i class="fas fa-edit me-2"></i>Edit Profil</h5></div>
      <div class="card-body">
        <form method="POST" action="../../ajax/update_profile.php" enctype="multipart/form-data" id="formProfile">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="id" value="<?= $my_data['id'] ?>">
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label fw-semibold">Nama Lengkap</label><input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($my_data['nama']) ?>"></div>
          <div class="col-md-6"><label class="form-label fw-semibold">NIK</label><input type="text" name="nik" class="form-control" value="<?= $my_data['nik']??'' ?>" maxlength="16"></div>
          <div class="col-md-6"><label class="form-label fw-semibold">No. HP</label><input type="text" name="no_hp" class="form-control" value="<?= $my_data['no_hp']??'' ?>"></div>
          <div class="col-12"><label class="form-label fw-semibold">Alamat</label><textarea name="alamat" class="form-control" rows="3"><?= htmlspecialchars($my_data['alamat']??'') ?></textarea></div>
          <div class="col-md-6"><label class="form-label fw-semibold">Foto Profil</label><input type="file" name="foto" class="form-control" accept=".jpg,.jpeg,.png"><small class="text-muted">Kosongkan jika tidak ubah foto</small></div>
          <div class="col-12"><hr><h6 class="fw-bold">Ganti Password</h6></div>
          <div class="col-md-4"><label class="form-label fw-semibold">Password Lama</label><input type="password" name="old_password" class="form-control"></div>
          <div class="col-md-4"><label class="form-label fw-semibold">Password Baru</label><input type="password" name="new_password" class="form-control"></div>
          <div class="col-md-4"><label class="form-label fw-semibold">Konfirmasi Password</label><input type="password" name="confirm_password" class="form-control"></div>
        </div>
        <div class="mt-4 d-flex justify-content-end"><button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-save me-2"></i>Simpan Perubahan</button></div>
        </form>
      </div>
    </div>
  </div>
</div>
</div></section>
<script>
$('#formProfile').on('submit', function(e) {
  e.preventDefault(); showLoading('Menyimpan profil...');
  $.ajax({url:this.action,type:'POST',data:new FormData(this),processData:false,contentType:false,
    success:function(r){hideLoading();if(r.success){Swal.fire({icon:'success',title:'Berhasil!',text:r.message,timer:2000,showConfirmButton:false}).then(()=>location.reload());}else{Swal.fire('Gagal!',r.message,'error');}},
    error:()=>{hideLoading();Swal.fire('Error!','Koneksi bermasalah','error');}
  });
});
</script>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
