<?php
$page_title = 'Tambah Kader';
require_once __DIR__ . '/../../includes/header.php';
if (!isAdmin()) { echo '<script>window.location="../../dashboard.php";</script>'; exit; }
?>
<section class="content-header"><div class="container-fluid"><div class="row mb-2">
  <div class="col-sm-6"><h1><i class="fas fa-user-plus me-2 text-primary"></i>Tambah Kader</h1></div>
  <div class="col-sm-6"><ol class="breadcrumb float-sm-end"><li class="breadcrumb-item"><a href="../../dashboard.php">Dashboard</a></li><li class="breadcrumb-item"><a href="index.php">Kader</a></li><li class="breadcrumb-item active">Tambah</li></ol></div>
</div></div></section>
<section class="content"><div class="container-fluid">
<div class="card">
  <div class="card-header bg-primary text-white"><h5 class="mb-0"><i class="fas fa-user-plus me-2"></i>Form Data Kader</h5></div>
  <div class="card-body">
    <form method="POST" action="../../ajax/save_kader.php" enctype="multipart/form-data" id="formKader">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
    <div class="row g-3">
      <div class="col-md-6"><label class="form-label fw-semibold">Nama Lengkap <span class="text-danger">*</span></label><input type="text" name="nama" class="form-control" required></div>
      <div class="col-md-6"><label class="form-label fw-semibold">NIK</label><input type="text" name="nik" class="form-control" maxlength="16"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Jenis Kelamin</label><select name="jenis_kelamin" class="form-select select2"><option value="P">Perempuan</option><option value="L">Laki-laki</option></select></div>
      <div class="col-md-4"><label class="form-label fw-semibold">No. HP</label><input type="text" name="no_hp" class="form-control"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Jabatan</label><select name="jabatan" class="form-select select2"><option>Kader</option><option>Ketua Kader</option><option>Bidan</option><option>Admin</option></select></div>
      <div class="col-12"><label class="form-label fw-semibold">Alamat</label><textarea name="alamat" class="form-control" rows="3"></textarea></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Username <span class="text-danger">*</span></label><input type="text" name="username" class="form-control" required autocomplete="off"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Password <span class="text-danger">*</span></label><div class="input-group"><input type="password" name="password" class="form-control" required autocomplete="new-password"><button type="button" class="btn btn-outline-secondary" onclick="this.previousElementSibling.type=this.previousElementSibling.type==='password'?'text':'password'"><i class="fas fa-eye"></i></button></div></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Role</label><select name="role" class="form-select select2"><option value="kader">Kader</option><option value="bidan">Bidan</option><option value="admin">Admin Desa</option><option value="kepala_desa">Kepala Desa</option></select></div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Foto Profil</label>
        <input type="file" name="foto" class="form-control" accept=".jpg,.jpeg,.png">
        <small class="text-muted">JPG, PNG (Max 2MB)</small>
      </div>
    </div>
    <div class="mt-4 d-flex gap-2 justify-content-end">
      <a href="index.php" class="btn btn-secondary btn-lg"><i class="fas fa-times me-2"></i>Batal</a>
      <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-save me-2"></i>Simpan</button>
    </div>
    </form>
  </div>
</div>
</div></section>
<script>
$('#formKader').on('submit', function(e) {
  e.preventDefault(); showLoading('Menyimpan data kader...');
  $.ajax({url:this.action,type:'POST',data:new FormData(this),processData:false,contentType:false,
    success:function(r){hideLoading();if(r.success){Swal.fire({icon:'success',title:'Berhasil!',text:r.message,timer:2000,showConfirmButton:false}).then(()=>window.location.href='index.php');}else{Swal.fire('Gagal!',r.message,'error');}},
    error:()=>{hideLoading();Swal.fire('Error!','Koneksi bermasalah','error');}
  });
});
</script>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
