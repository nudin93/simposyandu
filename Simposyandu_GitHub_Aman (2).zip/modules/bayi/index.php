<?php
$page_title = 'Data Bayi (0–12 Bulan)';
require_once __DIR__ . '/../../includes/header.php';
$data = [];
try {
  $data = fetchAll("SELECT b.*, TIMESTAMPDIFF(MONTH, b.tanggal_lahir, CURDATE()) as umur_bulan
    FROM bayi b WHERE b.status_aktif=1 ORDER BY b.created_at DESC");
} catch (Throwable $e) { $data = []; }
$canDel = function_exists('canInput') ? canInput() : true;
?>
<section class="content-header"><div class="container-fluid"><div class="row mb-2">
  <div class="col-sm-6"><h1><i class="fas fa-baby me-2 text-info"></i>Data Bayi (0–12 Bulan)</h1></div>
  <div class="col-sm-6"><ol class="breadcrumb float-sm-end"><li class="breadcrumb-item"><a href="<?= APP_URL ?>/dashboard.php">Dashboard</a></li><li class="breadcrumb-item active">Bayi</li></ol></div>
</div></div></section>
<section class="content"><div class="container-fluid">
<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h5 class="mb-0"><i class="fas fa-list me-2"></i>Daftar Bayi</h5>
    <?php if ($canDel): ?>
    <a href="tambah.php" class="btn btn-info"><i class="fas fa-plus me-1"></i>Tambah Bayi</a>
    <?php endif; ?>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-hover datatable" style="width:100%">
        <thead><tr><th>No</th><th>No. Peserta</th><th>Nama</th><th>L/P</th><th>Tgl Lahir</th><th>Umur</th><th>BB/PB Lahir</th><th>ASI</th><th>Ibu</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($data as $i => $r): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><span class="badge bg-info"><?= htmlspecialchars($r['nomor_peserta']) ?></span></td>
          <td class="fw-semibold"><?= htmlspecialchars($r['nama_lengkap']) ?></td>
          <td><?= $r['jenis_kelamin']=='L'?'<span class="badge bg-primary">L</span>':'<span class="badge bg-pink" style="background:#e91e63">P</span>' ?></td>
          <td><?= formatTanggal($r['tanggal_lahir']) ?></td>
          <td><?= (int)$r['umur_bulan'] ?> bln</td>
          <td><?= $r['berat_lahir'] ? $r['berat_lahir'].' kg' : '-' ?> / <?= $r['panjang_lahir'] ? $r['panjang_lahir'].' cm' : '-' ?></td>
          <td><?= htmlspecialchars($r['asi_eksklusif'] ?? '-') ?></td>
          <td><?= htmlspecialchars($r['nama_ibu'] ?? '-') ?></td>
          <td class="text-nowrap">
            <a href="../pemeriksaan_bayi/tambah.php?bayi_id=<?= $r['id'] ?>" class="btn btn-sm btn-success" title="Periksa"><i class="fas fa-stethoscope"></i></a>
            <a href="detail.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-info" title="Detail"><i class="fas fa-eye"></i></a>
            <?php if ($canDel): ?>
            <button type="button" class="btn btn-sm btn-danger" onclick="confirmDelete('<?= APP_URL ?>/ajax/delete.php?type=bayi&id=<?= (int)$r['id'] ?>','<?= htmlspecialchars($r['nama_lengkap'], ENT_QUOTES) ?>')" title="Hapus"><i class="fas fa-trash"></i></button>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div></section>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
