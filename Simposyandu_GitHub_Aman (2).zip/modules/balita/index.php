<?php
$page_title = 'Data Balita';
require_once __DIR__ . '/../../includes/header.php';
$data = fetchAll("SELECT b.*, TIMESTAMPDIFF(MONTH, b.tanggal_lahir, CURDATE()) as umur_bulan FROM balita b ORDER BY b.created_at DESC");
?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6"><h1><i class="fas fa-baby me-2 text-primary"></i>Data Balita</h1></div>
      <div class="col-sm-6"><ol class="breadcrumb float-sm-end"><li class="breadcrumb-item"><a href="<?= APP_URL ?>/dashboard.php">Dashboard</a></li><li class="breadcrumb-item active">Balita</li></ol></div>
    </div>
  </div>
</section>
<section class="content"><div class="container-fluid">
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
      <h5 class="mb-0"><i class="fas fa-list me-2"></i>Daftar Balita</h5>
      <div class="d-flex gap-2">
        <a href="<?= APP_URL ?>/modules/balita/tambah.php" class="btn btn-primary"><i class="fas fa-plus me-1"></i>Tambah Balita</a>
        <button class="btn btn-outline-success" onclick="exportExcel()"><i class="fas fa-file-excel me-1"></i>Export</button>
      </div>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-hover datatable" id="tblBalita">
          <thead><tr>
            <th>No</th><th>No. Peserta</th><th>Nama Anak</th><th>L/P</th><th>Tgl Lahir</th><th>Umur</th><th>Orang Tua</th><th>Status Gizi</th><th>Aksi</th>
          </tr></thead>
          <tbody>
            <?php foreach ($data as $i => $b): ?>
            <?php $umur = hitungUmur($b['tanggal_lahir']); ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><span class="badge bg-primary"><?= $b['nomor_peserta'] ?></span></td>
              <td>
                <div class="fw-semibold"><?= htmlspecialchars($b['nama_lengkap']) ?></div>
                <?php if ($b['foto_anak']): ?><small class="text-muted"><i class="fas fa-image me-1"></i>Ada foto</small><?php endif; ?>
              </td>
              <td><?= $b['jenis_kelamin'] == 'L' ? '<span class="badge bg-info">Laki-laki</span>' : '<span class="badge bg-pink" style="background:#e91e63">Perempuan</span>' ?></td>
              <td><?= formatTanggal($b['tanggal_lahir']) ?></td>
              <td><?= $umur ?></td>
              <td>
                <div class="small"><?= htmlspecialchars($b['nama_ibu'] ?? '-') ?></div>
                <small class="text-muted"><?= htmlspecialchars($b['no_hp'] ?? '') ?></small>
              </td>
              <td>
                <?php
                $pmx = fetchOne("SELECT status_gizi, risiko_stunting FROM pemeriksaan_balita WHERE balita_id={$b['id']} ORDER BY tanggal_pemeriksaan DESC LIMIT 1");
                if ($pmx) {
                    $sg = $pmx['status_gizi'];
                    $sc = $sg=='Normal'?'success':($sg=='Kurang'?'warning':'danger');
                    echo "<span class='badge bg-$sc'>$sg</span>";
                    if ($pmx['risiko_stunting'] != 'Tidak') echo " <span class='badge bg-danger'>Stunting</span>";
                } else echo '<span class="text-muted small">-</span>';
                ?>
              </td>
              <td>
                <div class="d-flex gap-1 flex-wrap">
                  <a href="detail.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-info" title="Detail"><i class="fas fa-eye"></i></a>
                  <a href="edit.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-warning" title="Edit"><i class="fas fa-edit"></i></a>
                  <a href="<?= APP_URL ?>/modules/pemeriksaan_balita/tambah.php?balita_id=<?= $b['id'] ?>" class="btn btn-sm btn-success" title="Periksa"><i class="fas fa-stethoscope"></i></a>
                  <a href="<?= APP_URL ?>/modules/kartu/cetak.php?type=balita&id=<?= $b['id'] ?>" class="btn btn-sm btn-secondary" title="Kartu" target="_blank"><i class="fas fa-id-card"></i></a>
                  <button class="btn btn-sm btn-danger" onclick="confirmDelete('<?= APP_URL ?>/ajax/delete.php?type=balita&id=<?= $b['id'] ?>','<?= htmlspecialchars($b['nama_lengkap']) ?>')" title="Hapus"><i class="fas fa-trash"></i></button>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div></section>
<script>
function exportExcel() {
  window.location.href = '<?= APP_URL ?>/ajax/export.php?type=balita';
}
</script>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
