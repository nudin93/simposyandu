<?php
$page_title = 'Tambah Data Balita';
require_once __DIR__ . '/../../includes/header.php';
$nomor = generateNomorPeserta('BLT', 'balita');
$provinsi_list = ['Aceh','Sumatera Utara','Sumatera Barat','Riau','Jambi','Sumatera Selatan','Bengkulu','Lampung','Kepulauan Bangka Belitung','Kepulauan Riau','DKI Jakarta','Jawa Barat','Jawa Tengah','DI Yogyakarta','Jawa Timur','Banten','Bali','Nusa Tenggara Barat','Nusa Tenggara Timur','Kalimantan Barat','Kalimantan Tengah','Kalimantan Selatan','Kalimantan Timur','Kalimantan Utara','Sulawesi Utara','Sulawesi Tengah','Sulawesi Selatan','Sulawesi Tenggara','Gorontalo','Sulawesi Barat','Maluku','Maluku Utara','Papua Barat','Papua','Papua Selatan','Papua Tengah','Papua Pegunungan'];
?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6"><h1><i class="fas fa-baby me-2 text-primary"></i>Tambah Data Balita</h1></div>
      <div class="col-sm-6"><ol class="breadcrumb float-sm-end">
        <li class="breadcrumb-item"><a href="<?= APP_URL ?>/dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="index.php">Balita</a></li>
        <li class="breadcrumb-item active">Tambah</li>
      </ol></div>
    </div>
  </div>
</section>
<section class="content"><div class="container-fluid">

<!-- Pilih dari Data Penduduk -->
<div class="card border-primary mb-3">
  <div class="card-header bg-primary text-white"><h5 class="mb-0"><i class="fas fa-search me-2"></i>Pilih dari Data Penduduk / Keluarga</h5></div>
  <div class="card-body">
    <p class="text-muted small mb-2">Cari anak yang sudah terdaftar sebagai anggota keluarga. Data identitas, orang tua, dan alamat terisi otomatis. Petugas hanya melengkapi data kesehatan.</p>
    <div class="row g-2">
      <div class="col-md-8 position-relative">
        <input type="text" id="cariPenduduk" class="form-control" placeholder="Ketik nama anak..." autocomplete="off">
        <div id="hasilCari" class="list-group position-absolute shadow w-100" style="z-index:1050; max-height:280px; overflow-y:auto; display:none;"></div>
      </div>
      <div class="col-md-4">
        <a href="<?= APP_URL ?>/modules/keluarga/index.php" class="btn btn-outline-secondary w-100" target="_blank"><i class="fas fa-home me-1"></i>Tambah via Data Keluarga</a>
      </div>
    </div>
    <div id="infoTerpilih" class="alert alert-success mt-3 mb-0 d-none"><i class="fas fa-check-circle me-1"></i>Terpilih: <strong id="namaTerpilih"></strong></div>
  </div>
</div>

<!-- Wizard Steps -->
<div class="wizard-steps mb-4" id="wizardSteps">
  <div class="wizard-step active" id="step-nav-1" onclick="goStep(1)"><i class="fas fa-baby me-1"></i>1. Biodata Anak</div>
  <div class="wizard-step" id="step-nav-2" onclick="goStep(2)"><i class="fas fa-users me-1"></i>2. Orang Tua</div>
  <div class="wizard-step" id="step-nav-3" onclick="goStep(3)"><i class="fas fa-map-marker-alt me-1"></i>3. Alamat</div>
  <div class="wizard-step" id="step-nav-4" onclick="goStep(4)"><i class="fas fa-heartbeat me-1"></i>4. Kesehatan</div>
  <div class="wizard-step" id="step-nav-5" onclick="goStep(5)"><i class="fas fa-upload me-1"></i>5. Upload</div>
</div>

<form method="POST" action="../../ajax/save_balita.php" enctype="multipart/form-data" id="formBalita" data-draft="1">
<input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

<!-- STEP 1: Biodata Anak -->
<div class="wizard-pane" id="pane-1">
<div class="card">
  <div class="card-header bg-primary text-white"><h5 class="mb-0"><i class="fas fa-baby me-2"></i>Biodata Anak</h5></div>
  <div class="card-body">
    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label fw-semibold">Nomor Peserta <span class="text-danger">*</span></label>
        <div class="input-group">
          <span class="input-group-text"><i class="fas fa-id-badge"></i></span>
          <input type="text" name="nomor_peserta" class="form-control" value="<?= $nomor ?>" readonly required>
          <button type="button" class="btn btn-outline-secondary" onclick="generateNomor()"><i class="fas fa-sync"></i></button>
        </div>
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold">NIK Anak</label>
        <div class="input-group">
          <span class="input-group-text"><i class="fas fa-fingerprint"></i></span>
          <input type="text" name="nik_anak" id="f_nik" class="form-control" placeholder="16 digit NIK" maxlength="16" pattern="\d{16}">
          <div class="invalid-feedback">NIK harus 16 digit angka</div>
        </div>
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold">No. Kartu Keluarga</label>
        <input type="text" name="no_kk" id="f_nokk" class="form-control" placeholder="16 digit No KK" maxlength="16">
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold">Nama Lengkap Anak <span class="text-danger">*</span></label>
        <input type="text" name="nama_lengkap" id="f_nama" class="form-control" placeholder="Nama lengkap tanpa gelar" required>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Jenis Kelamin <span class="text-danger">*</span></label>
        <select name="jenis_kelamin" class="form-select select2" required>
          <option value="">-- Pilih --</option>
          <option value="L">Laki-laki</option>
          <option value="P">Perempuan</option>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Tempat Lahir</label>
        <input type="text" name="tempat_lahir" class="form-control" placeholder="Kota tempat lahir">
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Tanggal Lahir <span class="text-danger">*</span></label>
        <input type="date" name="tanggal_lahir" id="tgl_lahir" class="form-control datepicker" required onchange="hitungUmurForm()">
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Umur (Otomatis)</label>
        <input type="text" id="umur_display" class="form-control bg-light" readonly placeholder="Otomatis dari tanggal lahir">
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Anak Ke-</label>
        <input type="number" name="anak_ke" class="form-control" value="1" min="1" max="20">
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Status Anak</label>
        <select name="status_anak" class="form-select select2">
          <option value="kandung">Kandung</option>
          <option value="angkat">Angkat</option>
          <option value="tiri">Tiri</option>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Golongan Darah</label>
        <select name="golongan_darah" class="form-select select2">
          <option value="Tidak Tahu">Tidak Tahu</option>
          <option value="A">A</option><option value="B">B</option>
          <option value="AB">AB</option><option value="O">O</option>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Berat Lahir (kg)</label>
        <div class="input-group"><input type="number" name="berat_lahir" class="form-control" placeholder="0.0" step="0.1" min="0.5" max="10"><span class="input-group-text">kg</span></div>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Tinggi Lahir (cm)</label>
        <div class="input-group"><input type="number" name="tinggi_lahir" class="form-control" placeholder="0" step="0.1" min="20" max="70"><span class="input-group-text">cm</span></div>
      </div>
    </div>
  </div>
  <div class="card-footer d-flex justify-content-end">
    <button type="button" class="btn btn-primary btn-lg" onclick="nextStep(1)"><i class="fas fa-arrow-right me-2"></i>Selanjutnya</button>
  </div>
</div>
</div>

<!-- STEP 2: Orang Tua -->
<div class="wizard-pane d-none" id="pane-2">
<div class="card">
  <div class="card-header bg-success text-white"><h5 class="mb-0"><i class="fas fa-users me-2"></i>Biodata Orang Tua</h5></div>
  <div class="card-body">
    <h6 class="fw-bold text-primary mb-3"><i class="fas fa-male me-2"></i>Data Ayah</h6>
    <div class="row g-3 mb-4">
      <div class="col-md-6"><label class="form-label fw-semibold">Nama Ayah</label><input type="text" name="nama_ayah" id="f_nama_ayah" class="form-control" placeholder="Nama lengkap ayah"></div>
      <div class="col-md-6"><label class="form-label fw-semibold">NIK Ayah</label><input type="text" name="nik_ayah" id="f_nik_ayah" class="form-control" placeholder="16 digit NIK" maxlength="16"></div>
      <div class="col-md-6"><label class="form-label fw-semibold">Pekerjaan Ayah</label><select name="pekerjaan_ayah" class="form-select select2"><option value="">-- Pilih --</option><?php foreach(['PNS','TNI/Polri','Petani','Nelayan','Pedagang','Wiraswasta','Buruh','Karyawan Swasta','Guru','Dokter/Tenaga Medis','Lainnya'] as $p): ?><option><?= $p ?></option><?php endforeach; ?></select></div>
    </div>
    <hr>
    <h6 class="fw-bold text-danger mb-3"><i class="fas fa-female me-2"></i>Data Ibu</h6>
    <div class="row g-3">
      <div class="col-md-6"><label class="form-label fw-semibold">Nama Ibu</label><input type="text" name="nama_ibu" id="f_nama_ibu" class="form-control" placeholder="Nama lengkap ibu"></div>
      <div class="col-md-6"><label class="form-label fw-semibold">NIK Ibu</label><input type="text" name="nik_ibu" id="f_nik_ibu" class="form-control" placeholder="16 digit NIK" maxlength="16"></div>
      <div class="col-md-6"><label class="form-label fw-semibold">Pekerjaan Ibu</label><select name="pekerjaan_ibu" class="form-select select2"><option value="">-- Pilih --</option><?php foreach(['Ibu Rumah Tangga','PNS','Petani','Pedagang','Wiraswasta','Buruh','Karyawan Swasta','Guru','Dokter/Tenaga Medis','Lainnya'] as $p): ?><option><?= $p ?></option><?php endforeach; ?></select></div>
      <div class="col-md-6"><label class="form-label fw-semibold">Nomor HP Orang Tua</label><div class="input-group"><span class="input-group-text"><i class="fas fa-phone"></i></span><input type="text" name="no_hp" class="form-control" placeholder="08xxxxxxxxxx"></div></div>
    </div>
  </div>
  <div class="card-footer d-flex justify-content-between">
    <button type="button" class="btn btn-secondary btn-lg" onclick="prevStep(2)"><i class="fas fa-arrow-left me-2"></i>Kembali</button>
    <button type="button" class="btn btn-success btn-lg" onclick="nextStep(2)"><i class="fas fa-arrow-right me-2"></i>Selanjutnya</button>
  </div>
</div>
</div>

<!-- STEP 3: Alamat -->
<div class="wizard-pane d-none" id="pane-3">
<div class="card">
  <div class="card-header bg-warning"><h5 class="mb-0"><i class="fas fa-map-marker-alt me-2"></i>Alamat</h5></div>
  <div class="card-body">
    <div class="row g-3">
      <div class="col-md-3"><label class="form-label fw-semibold">Dusun</label><input type="text" name="dusun" id="f_dusun" class="form-control" placeholder="Nama dusun/lingkungan"></div>
      <div class="col-md-2"><label class="form-label fw-semibold">RT</label><input type="text" name="rt" class="form-control" placeholder="001" maxlength="5"></div>
      <div class="col-md-2"><label class="form-label fw-semibold">RW</label><input type="text" name="rw" class="form-control" placeholder="001" maxlength="5"></div>
      <div class="col-md-5"><label class="form-label fw-semibold">Desa/Kelurahan</label><input type="text" name="desa" class="form-control" value="<?= $pengaturan['nama_desa'] ?>" placeholder="Nama desa"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Kecamatan</label><input type="text" name="kecamatan" class="form-control" value="<?= $pengaturan['kecamatan'] ?>"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Kabupaten/Kota</label><input type="text" name="kabupaten" class="form-control" value="<?= $pengaturan['kabupaten'] ?>"></div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Provinsi</label>
        <select name="provinsi" class="form-select select2">
          <?php foreach ($provinsi_list as $p): ?><option <?= $p==$pengaturan['provinsi']?'selected':'' ?>><?= $p ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-12">
        <label class="form-label fw-semibold">Alamat Lengkap</label>
        <textarea name="alamat_lengkap" id="f_alamat" class="form-control" rows="3" placeholder="Jalan, nomor rumah, RT/RW, dusun..."></textarea>
      </div>
    </div>
  </div>
  <div class="card-footer d-flex justify-content-between">
    <button type="button" class="btn btn-secondary btn-lg" onclick="prevStep(3)"><i class="fas fa-arrow-left me-2"></i>Kembali</button>
    <button type="button" class="btn btn-warning btn-lg" onclick="nextStep(3)"><i class="fas fa-arrow-right me-2"></i>Selanjutnya</button>
  </div>
</div>
</div>

<!-- STEP 4: Kesehatan -->
<div class="wizard-pane d-none" id="pane-4">
<div class="card">
  <div class="card-header bg-danger text-white"><h5 class="mb-0"><i class="fas fa-heartbeat me-2"></i>Data Kesehatan</h5></div>
  <div class="card-body">
    <div class="row g-3">
      <div class="col-md-4">
        <label class="form-label fw-semibold">Status ASI</label>
        <select name="status_asi" class="form-select select2">
          <option>ASI Eksklusif</option><option>Susu Formula</option><option>Keduanya</option>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Status Imunisasi</label>
        <select name="status_imunisasi" class="form-select select2">
          <option>Dalam Proses</option><option>Lengkap</option><option>Belum Lengkap</option>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">No. BPJS/KIS</label>
        <input type="text" name="bpjs_kis" class="form-control" placeholder="Nomor BPJS/KIS">
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold">Riwayat Alergi</label>
        <textarea name="riwayat_alergi" class="form-control" rows="3" placeholder="Alergi makanan, obat, dll. (kosongkan jika tidak ada)"></textarea>
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold">Riwayat Penyakit</label>
        <textarea name="riwayat_penyakit" class="form-control" rows="3" placeholder="Riwayat penyakit sebelumnya (kosongkan jika tidak ada)"></textarea>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Status Aktif</label>
        <div class="form-check form-switch mt-2">
          <input class="form-check-input" type="checkbox" name="status_aktif" id="statusAktif" value="1" checked>
          <label class="form-check-label fw-semibold" for="statusAktif">Aktif di Posyandu</label>
        </div>
      </div>
    </div>
  </div>
  <div class="card-footer d-flex justify-content-between">
    <button type="button" class="btn btn-secondary btn-lg" onclick="prevStep(4)"><i class="fas fa-arrow-left me-2"></i>Kembali</button>
    <button type="button" class="btn btn-danger btn-lg" onclick="nextStep(4)"><i class="fas fa-arrow-right me-2"></i>Selanjutnya</button>
  </div>
</div>
</div>

<!-- STEP 5: Upload -->
<div class="wizard-pane d-none" id="pane-5">
<div class="card">
  <div class="card-header bg-secondary text-white"><h5 class="mb-0"><i class="fas fa-upload me-2"></i>Upload Dokumen</h5></div>
  <div class="card-body">
    <div class="row g-3">
      <?php foreach([['foto_anak','Foto Anak','fas fa-camera','jpg, jpeg, png'],['foto_kk','Kartu Keluarga','fas fa-file-image','jpg, jpeg, png, pdf'],['foto_bpjs','Kartu BPJS/KIS','fas fa-id-card','jpg, jpeg, png, pdf']] as [$name,$label,$icon,$types]): ?>
      <div class="col-md-4">
        <div class="card border-dashed" style="border:2px dashed #dee2e6;border-radius:12px">
          <div class="card-body text-center p-4">
            <i class="<?= $icon ?> fa-3x text-muted mb-3 d-block"></i>
            <label class="form-label fw-semibold"><?= $label ?></label>
            <input type="file" name="<?= $name ?>" class="form-control" accept=".jpg,.jpeg,.png,.pdf" onchange="previewImg(this, '<?= $name ?>_prev')">
            <small class="text-muted mt-1 d-block"><?= $types ?> (Max 5MB)</small>
            <img id="<?= $name ?>_prev" src="" class="img-fluid mt-2 d-none" style="max-height:150px;border-radius:8px">
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
</div>
  <div class="card-footer d-flex justify-content-between align-items-center">
    <button type="button" class="btn btn-secondary btn-lg" onclick="prevStep(5)"><i class="fas fa-arrow-left me-2"></i>Kembali</button>
    <div class="d-flex gap-2">
      <button type="button" class="btn btn-outline-secondary btn-lg" onclick="saveDraft()"><i class="fas fa-save me-2"></i>Simpan Draft</button>
      <button type="submit" class="btn btn-primary btn-lg" id="btnSimpan"><i class="fas fa-check me-2"></i>Simpan Data</button>
    </div>
  </div>
</div>
</div>
</form>
</div></section>
<?php
ob_start();
?>
<script>
let currentStep = 1; const totalSteps = 5;
function goStep(n) {
  $('#pane-' + currentStep).addClass('d-none'); $('#step-nav-' + currentStep).removeClass('active').addClass('done');
  currentStep = n;
  $('#pane-' + n).removeClass('d-none'); $('#step-nav-' + n).addClass('active').removeClass('done');
}
function nextStep(n) {
  if (!validateStep(n)) return;
  goStep(n + 1);
  window.scrollTo(0, 0);
}
function prevStep(n) { goStep(n - 1); window.scrollTo(0, 0); }
function validateStep(n) {
  let valid = true;
  $('#pane-' + n + ' [required]').each(function() {
    if (!$(this).val()) { $(this).addClass('is-invalid'); valid = false; }
    else $(this).removeClass('is-invalid');
  });
  if (!valid) { Swal.fire('Perhatian!', 'Lengkapi semua field yang wajib diisi', 'warning'); }
  return valid;
}
function hitungUmurForm() {
  const tgl = $('#tgl_lahir').val();
  if (tgl) { const umur = hitungUmur(tgl); $('#umur_display').val(umur); }
}
function previewImg(input, prevId) {
  const file = input.files[0];
  if (file && file.type.startsWith('image/')) {
    const reader = new FileReader();
    reader.onload = e => { $('#'+prevId).attr('src', e.target.result).removeClass('d-none'); };
    reader.readAsDataURL(file);
  }
}
function generateNomor() {
  $.get('../../ajax/generate_nomor.php?type=balita', function(r) {
    if (r.nomor) $('[name=nomor_peserta]').val(r.nomor);
  }, 'json');
}
function saveDraft() {
  const key = 'draft_balita';
  const data = {};
  $('#formBalita').find('input,select,textarea').each(function() {
    const n = $(this).attr('name'); if (n && $(this).attr('type') !== 'file') data[n] = $(this).val();
  });
  localStorage.setItem(key, JSON.stringify(data));
  Swal.fire({ icon: 'success', title: 'Draft Tersimpan!', text: 'Data dapat dilanjutkan nanti', timer: 2000, showConfirmButton: false });
}
$(document).ready(function() {
  $('#formBalita').on('submit', function(e) {
    e.preventDefault();
    showLoading('Menyimpan data balita...');
    $.ajax({
      url: this.action, type: 'POST', data: new FormData(this), processData: false, contentType: false,
      success: function(r) {
        hideLoading();
        if (r.success) {
          Swal.fire({ icon: 'success', title: 'Berhasil!', text: r.message, showConfirmButton: false, timer: 2000 })
            .then(() => window.location.href = 'index.php');
        } else { Swal.fire('Gagal!', r.message || 'Terjadi kesalahan', 'error'); }
      },
      error: () => { hideLoading(); Swal.fire('Error!', 'Koneksi bermasalah', 'error'); }
    });
  });
});
</script>
<script>
/* using shared helper if available */
var timerCari = null;
$('#cariPenduduk').on('input', function() {
  clearTimeout(timerCari);
  var q = $(this).val().trim();
  if (q.length < 1) { $('#hasilCari').hide().empty(); return; }
  timerCari = setTimeout(function() {
    $.getJSON('<?= APP_URL ?>/ajax/cari_penduduk.php', {q: q}, function(res) {
      var box = $('#hasilCari').empty();
      if (!res.data || !res.data.length) {
        box.append('<div class="list-group-item text-muted">Tidak ditemukan. Daftarkan anak di Data Keluarga (Tambah Anggota).</div>').show();
        return;
      }
      res.data.forEach(function(p) {
        var item = $('<a href="#" class="list-group-item list-group-item-action"></a>');
        item.html('<strong>'+p.nama+'</strong> <code class="ms-1">'+p.nik+'</code><br><small class="text-muted">KK: '+(p.no_kk||'-')+' | '+(p.umur||'?')+' th | Hub: '+(p.status_dalam_keluarga||'')+' | '+(p.dusun||'')+'</small>');
        item.on('click', function(e) {
          e.preventDefault();
          $('#f_nik').val(p.nik||'');
          $('#f_nokk').val(p.no_kk||'');
          $('#f_nama').val(p.nama||'');
          if (p.jenis_kelamin) $('select[name="jenis_kelamin"]').val(p.jenis_kelamin).trigger('change');
          $('input[name="tempat_lahir"]').val(p.tempat_lahir||'');
          $('#tgl_lahir').val(p.tanggal_lahir||'');
          if (typeof hitungUmurForm === 'function') hitungUmurForm();
          $('#f_nama_ayah').val(p.nama_ayah||'');
          $('#f_nik_ayah').val(p.nik_ayah||'');
          $('#f_nama_ibu').val(p.nama_ibu||'');
          $('#f_nik_ibu').val(p.nik_ibu||'');
          $('#f_dusun').val(p.dusun||'');
          $('input[name="rt"]').val(p.rt||'');
          $('input[name="rw"]').val(p.rw||'');
          $('#f_alamat').val(p.alamat||'');
          $('input[name="no_hp"]').val(p.no_hp||'');
          $('#infoTerpilih').removeClass('d-none');
          $('#namaTerpilih').text(p.nama+' ('+p.nik+')');
          box.hide();
          $('#cariPenduduk').val(p.nama);
        });
        box.append(item);
      });
      box.show();
    });
  }, 200);
});
$(document).on('click', function(e) {
  if (!$(e.target).closest('#cariPenduduk, #hasilCari').length) $('#hasilCari').hide();
});
</script>
<?php
$extra_js = ob_get_clean();
include __DIR__ . '/../../includes/footer.php';
