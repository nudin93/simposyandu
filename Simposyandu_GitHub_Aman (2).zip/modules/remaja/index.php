<?php
$page_title = 'Anak Sekolah & Remaja';
require_once __DIR__ . '/../../includes/header.php';
$data = [];
try { $data = fetchAll("SELECT *, TIMESTAMPDIFF(YEAR, tanggal_lahir, CURDATE()) as umur FROM remaja WHERE status_aktif=1 ORDER BY created_at DESC"); } catch(Throwable $e){}
$canDel = function_exists('canInput') ? canInput() : true;
?>
<section class="content-header"><div class="container-fluid"><div class="row mb-2">
  <div class="col-sm-6"><h1><i class="fas fa-user-graduate me-2 text-warning"></i>Anak Sekolah & Remaja</h1></div>
</div></div></section>
<section class="content"><div class="container-fluid">
<div class="card">
  <div class="card-header d-flex justify-content-between"><h5 class="mb-0">Daftar</h5>
    <?php if ($canDel): ?><a href="tambah.php" class="btn btn-warning btn-sm"><i class="fas fa-plus"></i> Tambah</a><?php endif; ?>
  </div>
  <div class="card-body table-responsive">
    <table class="table table-hover datatable" style="width:100%">
      <thead><tr><th>No</th><th>No.Peserta</th><th>Nama</th><th>JK</th><th>Umur</th><th>Kategori</th><th>Sekolah</th><th>Aksi</th></tr></thead>
      <tbody>
    <?php foreach($data as $i=>$r): ?>
    <tr>
      <td><?= $i+1 ?></td>
      <td><span class="badge bg-warning text-dark"><?= htmlspecialchars($r['nomor_peserta']) ?></span></td>
      <td><?= htmlspecialchars($r['nama_lengkap']) ?></td>
      <td><?= $r['jenis_kelamin'] ?></td>
      <td><?= $r['umur'] ?> th</td>
      <td><?= htmlspecialchars($r['kategori']) ?></td>
      <td><?= htmlspecialchars($r['sekolah']??'-') ?></td>
      <td class="text-nowrap">
        <a href="../pemeriksaan_remaja/tambah.php?remaja_id=<?= $r['id'] ?>" class="btn btn-sm btn-success" title="Periksa"><i class="fas fa-stethoscope"></i></a>
        <?php if ($canDel): ?>
        <button type="button" class="btn btn-sm btn-danger" onclick="confirmDelete('<?= APP_URL ?>/ajax/delete.php?type=remaja&id=<?= (int)$r['id'] ?>','<?= htmlspecialchars($r['nama_lengkap'], ENT_QUOTES) ?>')" title="Hapus"><i class="fas fa-trash"></i></button>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</div></section>
<?php include __DIR__.'/../../includes/footer.php'; ?>
