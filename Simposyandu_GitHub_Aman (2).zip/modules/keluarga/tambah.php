<?php
require_once __DIR__ . '/../../config/init.php';
requireLogin();
header('Location: index.php?msg=Data+keluarga+hanya+dikelola+melalui+OpenSID');
exit;
