<?php
$page_title = 'Data Lansia';
require_once __DIR__ . '/../../includes/header.php';
$data = fetchAll("SELECT *, TIMESTAMPDIFF(YEAR, tanggal_lahir, CURDATE()) as usia FROM lansia ORDER BY created_at DESC");
?>
<section class="content-header"><div class="container-fluid"><div class="row mb-2">
  <div class="col-sm-6"><h1><i class="fas fa-user-injured me-2 text-warning"></i>Data Lansia</h1></div>
  <div class="col-sm-6"><ol class="breadcrumb float-sm-end"><li class="breadcrumb-item"><a href="../../dashboard.php">Dashboard</a></li><li class="breadcrumb-item active">Lansia</li></ol></div>
</div></div></section>
<section class="content"><div class="container-fluid">
<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h5 class="mb-0"><i class="fas fa-list me-2"></i>Daftar Lansia</h5>
    <a href="tambah.php" class="btn btn-warning"><i class="fas fa-plus me-1"></i>Tambah Lansia</a>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-hover datatable">
        <thead><tr><th>No</th><th>No. Peserta</th><th>Nama</th><th>L/P</th><th>Tgl Lahir</th><th>Usia</th><th>Alamat</th><th>Kondisi Terakhir</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($data as $i => $l): ?>
        <?php $last = fetchOne("SELECT risiko_hipertensi, risiko_diabetes, tekanan_darah FROM pemeriksaan_lansia WHERE lansia_id={$l['id']} ORDER BY tanggal_pemeriksaan DESC LIMIT 1"); ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><span class="badge bg-warning text-dark"><?= $l['nomor_peserta'] ?></span></td>
          <td><div class="fw-semibold"><?= htmlspecialchars($l['nama']) ?></div></td>
          <td><?= $l['jenis_kelamin']=='L'?'<span class="badge bg-info">L</span>':'<span class="badge bg-pink" style="background:#e91e63">P</span>' ?></td>
          <td><?= formatTanggal($l['tanggal_lahir']) ?></td>
          <td><?= $l['usia'] ?> tahun</td>
          <td><?= htmlspecialchars(substr($l['alamat_lengkap']??'',0,50)) ?></td>
          <td>
            <?php if ($last): ?>
            <?php if ($last['risiko_hipertensi']) echo '<span class="badge bg-danger me-1">Hipertensi</span>'; ?>
            <?php if ($last['risiko_diabetes']) echo '<span class="badge bg-warning text-dark me-1">Diabetes</span>'; ?>
            <?php if (!$last['risiko_hipertensi'] && !$last['risiko_diabetes']) echo '<span class="badge bg-success">Normal</span>'; ?>
            <?php else: ?><span class="badge bg-secondary">Belum Periksa</span><?php endif; ?>
          </td>
          <td>
            <a href="detail.php?id=<?= $l['id'] ?>" class="btn btn-sm btn-info"><i class="fas fa-eye"></i></a>
            <a href="edit.php?id=<?= $l['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
            <a href="../pemeriksaan_lansia/tambah.php?lansia_id=<?= $l['id'] ?>" class="btn btn-sm btn-success"><i class="fas fa-stethoscope"></i></a>
            <a href="../kartu/cetak.php?type=lansia&id=<?= $l['id'] ?>" class="btn btn-sm btn-secondary" target="_blank"><i class="fas fa-id-card"></i></a>
            <button type="button" class="btn btn-sm btn-danger" onclick="confirmDelete('<?= APP_URL ?>/ajax/delete.php?type=lansia&id=<?= $l['id'] ?>','<?= htmlspecialchars($l['nama'], ENT_QUOTES) ?>')" title="Hapus"><i class="fas fa-trash"></i></button>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div></section>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
