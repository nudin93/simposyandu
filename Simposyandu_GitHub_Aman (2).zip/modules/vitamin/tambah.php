<?php
$page_title = 'Tambah Vitamin';
require_once __DIR__ . '/../../includes/header.php';
$balita_list = fetchAll("SELECT id, nama_lengkap, nomor_peserta FROM balita WHERE status_aktif=1 ORDER BY nama_lengkap");
$kader_list = fetchAll("SELECT id, nama FROM kader WHERE status=1");
?>
<section class="content-header"><div class="container-fluid"><div class="row mb-2">
  <div class="col-sm-6"><h1><i class="fas fa-pills me-2 text-success"></i>Tambah Vitamin</h1></div>
  <div class="col-sm-6"><ol class="breadcrumb float-sm-end"><li class="breadcrumb-item"><a href="../../dashboard.php">Dashboard</a></li><li class="breadcrumb-item"><a href="index.php">Vitamin</a></li><li class="breadcrumb-item active">Tambah</li></ol></div>
</div></div></section>
<section class="content"><div class="container-fluid">
<div class="card">
  <div class="card-header bg-success text-white"><h5 class="mb-0"><i class="fas fa-pills me-2"></i>Form Pemberian Vitamin</h5></div>
  <div class="card-body">
    <form method="POST" action="../../ajax/save_vitamin.php" id="formVitamin">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
    <div class="row g-3">
      <div class="col-md-6"><label class="form-label fw-semibold">Nama Balita <span class="text-danger">*</span></label><select name="balita_id" class="form-select select2" required><option value="">-- Pilih Balita --</option><?php foreach ($balita_list as $b): ?><option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['nama_lengkap']) ?> (<?= $b['nomor_peserta'] ?>)</option><?php endforeach; ?></select></div>
      <div class="col-md-6"><label class="form-label fw-semibold">Jenis Vitamin <span class="text-danger">*</span></label><select name="jenis_vitamin" class="form-select select2" required><option value="">-- Pilih --</option><?php foreach(['Vitamin A (Merah)','Vitamin A (Biru)','Vitamin D','Vitamin C','Zinc','Tablet Fe','Asam Folat','Multivitamin','Lainnya'] as $jv): ?><option><?= $jv ?></option><?php endforeach; ?></select></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Dosis</label><input type="text" name="dosis" class="form-control" placeholder="Contoh: 1 kapsul"></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Tanggal Pemberian <span class="text-danger">*</span></label><input type="date" name="tanggal_pemberian" class="form-control datepicker" value="<?= date('Y-m-d') ?>" required></div>
      <div class="col-md-4"><label class="form-label fw-semibold">Petugas</label><select name="petugas_id" class="form-select select2"><?php foreach ($kader_list as $k): ?><option value="<?= $k['id'] ?>" <?= $k['id']==$user['id']?'selected':'' ?>><?= htmlspecialchars($k['nama']) ?></option><?php endforeach; ?></select></div>
      <div class="col-12"><label class="form-label fw-semibold">Catatan</label><textarea name="catatan" class="form-control" rows="3"></textarea></div>
    </div>
    <div class="mt-4 d-flex gap-2 justify-content-end">
      <a href="index.php" class="btn btn-secondary btn-lg"><i class="fas fa-times me-2"></i>Batal</a>
      <button type="submit" class="btn btn-success btn-lg"><i class="fas fa-save me-2"></i>Simpan</button>
    </div>
    </form>
  </div>
</div>
</div></section>
<script>
$(document).ready(function() {
  $('#formVitamin').on('submit', function(e) {
    e.preventDefault(); showLoading('Menyimpan...');
    $.ajax({url:this.action,type:'POST',data:new FormData(this),processData:false,contentType:false,
      success:function(r){hideLoading();if(r.success){Swal.fire({icon:'success',title:'Berhasil!',text:r.message,timer:2000,showConfirmButton:false}).then(()=>window.location.href='index.php');}else{Swal.fire('Gagal!',r.message,'error');}},
      error:()=>{hideLoading();Swal.fire('Error!','Koneksi bermasalah','error');}
    });
  });
});
</script>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
