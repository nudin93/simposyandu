<?php
$page_title='Pemeriksaan Remaja'; require_once __DIR__.'/../../includes/header.php';
$data=[]; try{$data=fetchAll("SELECT pr.*, r.nama_lengkap FROM pemeriksaan_remaja pr JOIN remaja r ON r.id=pr.remaja_id ORDER BY pr.tanggal_pemeriksaan DESC LIMIT 500");}catch(Throwable $e){}
$canDel = function_exists('canInput') ? canInput() : true;
?>
<section class="content-header"><div class="container-fluid"><h1>Pemeriksaan Remaja</h1></div></section>
<section class="content"><div class="container-fluid"><div class="card"><div class="card-body table-responsive">
<table class="table table-hover datatable" style="width:100%">
<thead><tr><th>No</th><th>Tanggal</th><th>Nama</th><th>BB</th><th>TB</th><th>IMT</th><th>Gizi</th><th>Anemia</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach($data as $i=>$r): ?>
<tr>
<td><?= $i+1 ?></td>
<td><?= formatTanggal($r['tanggal_pemeriksaan']) ?></td>
<td><?= htmlspecialchars($r['nama_lengkap']) ?></td>
<td><?= $r['berat_badan'] ?></td>
<td><?= $r['tinggi_badan'] ?></td>
<td><?= $r['imt'] ?></td>
<td><?= $r['status_gizi'] ?></td>
<td><?= $r['status_anemia']?'Ya':'Tidak' ?></td>
<td>
<?php if($canDel):?>
<button type="button" class="btn btn-sm btn-danger" onclick="confirmDelete('<?= APP_URL ?>/ajax/delete.php?type=pemeriksaan_remaja&id=<?= (int)$r['id'] ?>','Pemeriksaan <?= htmlspecialchars($r['nama_lengkap'], ENT_QUOTES) ?>')" title="Hapus"><i class="fas fa-trash"></i></button>
<?php endif;?>
</td>
</tr>
<?php endforeach; ?>
</tbody></table>
</div></div></div></section>
<?php include __DIR__.'/../../includes/footer.php'; ?>
