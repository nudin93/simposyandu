<?php
$page_title='Periksa Remaja'; require_once __DIR__.'/../../includes/header.php';
$id=(int)($_GET['remaja_id']??0); $r=$id?fetchOne("SELECT * FROM remaja WHERE id=$id"):null;
if(!$r){echo '<div class="alert alert-warning m-3">Pilih remaja dulu.</div>';include __DIR__.'/../../includes/footer.php';exit;}
?>
<section class="content"><div class="container-fluid"><div class="card"><div class="card-header">Pemeriksaan: <?= htmlspecialchars($r['nama_lengkap']) ?></div><div class="card-body">
<form id="f" action="<?= APP_URL ?>/ajax/save_pemeriksaan_remaja.php" method="post">
<input type="hidden" name="remaja_id" value="<?= $id ?>">
<div class="row g-3">
<div class="col-md-3"><label>Tanggal</label><input type="date" name="tanggal_pemeriksaan" class="form-control" value="<?= date('Y-m-d') ?>" required></div>
<div class="col-md-3"><label>BB (kg)</label><input type="number" step="0.1" name="berat_badan" id="bb" class="form-control"></div>
<div class="col-md-3"><label>TB (cm)</label><input type="number" step="0.1" name="tinggi_badan" id="tb" class="form-control"></div>
<div class="col-md-3"><label>IMT</label><input type="text" name="imt" id="imt" class="form-control" readonly></div>
<div class="col-md-3"><label>Hb</label><input type="number" step="0.1" name="hb" class="form-control"></div>
<div class="col-md-3"><label>Tekanan Darah</label><input name="tekanan_darah" class="form-control" placeholder="120/80"></div>
<div class="col-md-6"><label>Edukasi Kesehatan</label><textarea name="edukasi_kesehatan" class="form-control" rows="2"></textarea></div>
<div class="col-md-6"><label>Keluhan</label><textarea name="keluhan" class="form-control" rows="2"></textarea></div>
</div>
<button class="btn btn-warning mt-3">Simpan</button>
</form></div></div></div></section>
<script>
bb.oninput=tb.oninput=()=>{const b=+bb.value,t=+tb.value;imt.value=(b&&t)?(b/((t/100)**2)).toFixed(2):'';};
f.onsubmit=e=>{e.preventDefault();ajaxSubmitForm(f,{redirect:'../remaja/index.php'});};
</script>
<?php include __DIR__.'/../../includes/footer.php'; ?>
