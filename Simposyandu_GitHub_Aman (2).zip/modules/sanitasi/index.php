<?php
$page_title = 'Data Sanitasi';
require_once __DIR__ . '/../../includes/header.php';

$__chk = @query("SHOW TABLES LIKE 'sanitasi'");
if (!$__chk || $__chk->num_rows == 0) {
    echo '<section class="content"><div class="container-fluid"><div class="alert alert-warning mt-3">';
    echo 'Tabel <b>sanitasi</b> belum ada. Jalankan file <code>database/migrasi_tabel_baru.sql</code> di phpMyAdmin.';
    echo ' <a href="' . APP_URL . '/modules/pengaturan/index.php" class="alert-link">Kembali</a></div></div></section>';
    include __DIR__ . '/../../includes/footer.php';
    exit;
}

$q = trim($_GET['q'] ?? '');
if ($q !== '') {
  $s = escape($q);
  $data = fetchAll("SELECT * FROM sanitasi WHERE nama_kepala LIKE '%$s%' OR no_kk LIKE '%$s%' OR dusun LIKE '%$s%' ORDER BY nama_kepala");
} else {
  $data = fetchAll("SELECT * FROM sanitasi ORDER BY dusun, nama_kepala");
}
$stats = array(
  'jamban_sendiri' => numRows("SELECT id FROM sanitasi WHERE kepemilikan_jamban='Jamban Sendiri'"),
  'tanpa_jamban' => numRows("SELECT id FROM sanitasi WHERE kepemilikan_jamban='Tidak Memiliki'"),
  'air_layak' => numRows("SELECT id FROM sanitasi WHERE kondisi_air='Layak'"),
  'total' => numRows("SELECT id FROM sanitasi"),
);
?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6"><h1><i class="fas fa-toilet me-2 text-primary"></i>Data Sanitasi & Kesehatan Lingkungan</h1></div>
      <div class="col-sm-6"><ol class="breadcrumb float-sm-end"><li class="breadcrumb-item"><a href="<?= APP_URL ?>/dashboard.php">Dashboard</a></li><li class="breadcrumb-item active">Sanitasi</li></ol></div>
    </div>
  </div>
</section>
<section class="content"><div class="container-fluid">
<?php if (!empty($_GET['msg']) && $_GET['msg'] === 'success'): ?>
  <div class="alert alert-success">Data berhasil disimpan.</div>
<?php endif; ?>
  <div class="row mb-3">
    <div class="col-6 col-md-3"><div class="small-box bg-success"><div class="inner"><h3><?= (int)$stats['jamban_sendiri'] ?></h3><p>Jamban Sendiri</p></div></div></div>
    <div class="col-6 col-md-3"><div class="small-box bg-danger"><div class="inner"><h3><?= (int)$stats['tanpa_jamban'] ?></h3><p>Tanpa Jamban</p></div></div></div>
    <div class="col-6 col-md-3"><div class="small-box bg-info"><div class="inner"><h3><?= (int)$stats['air_layak'] ?></h3><p>Air Layak</p></div></div></div>
    <div class="col-6 col-md-3"><div class="small-box bg-primary"><div class="inner"><h3><?= (int)$stats['total'] ?></h3><p>Total Data</p></div></div></div>
  </div>
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
      <h5 class="mb-0"><i class="fas fa-list me-2"></i>Daftar Sanitasi Keluarga</h5>
      <div class="d-flex gap-2">
        <form method="get" class="d-flex gap-1">
          <input type="text" name="q" class="form-control form-control-sm" placeholder="Cari nama kepala / KK..." value="<?= htmlspecialchars($q) ?>" style="width:200px">
          <button class="btn btn-sm btn-outline-primary"><i class="fas fa-search"></i></button>
        </form>
        <a href="tambah.php" class="btn btn-primary btn-sm"><i class="fas fa-plus me-1"></i>Tambah / Update</a>
      </div>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-hover datatable table-sm">
          <thead><tr>
            <th>No</th><th>No. KK</th><th>Kepala Keluarga</th><th>Dusun</th><th>Jamban</th><th>Jenis</th><th>Sumber Air</th><th>Sampah</th><th>Aksi</th>
          </tr></thead>
          <tbody>
          <?php foreach ($data as $i => $s): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($s['no_kk']) ?></code></td>
              <td><?= htmlspecialchars($s['nama_kepala'] ?? '-') ?></td>
              <td><?= htmlspecialchars($s['dusun'] ?? '-') ?></td>
              <td><?= htmlspecialchars($s['kepemilikan_jamban'] ?? '-') ?></td>
              <td><?= htmlspecialchars($s['jenis_jamban'] ?? '-') ?></td>
              <td><?= htmlspecialchars($s['sumber_air'] ?? '-') ?> <small>(<?= htmlspecialchars($s['kondisi_air'] ?? '-') ?>)</small></td>
              <td><?= htmlspecialchars($s['pengelolaan_sampah'] ?? '-') ?></td>
              <td>
                <a href="tambah.php?no_kk=<?= urlencode($s['no_kk']) ?>" class="btn btn-xs btn-warning" title="Edit"><i class="fas fa-edit"></i></a>
                <button type="button" class="btn btn-xs btn-danger" onclick="confirmDelete('<?= APP_URL ?>/ajax/delete.php?type=sanitasi&id=<?= (int)$s['id'] ?>','Sanitasi <?= htmlspecialchars($s['nama_kepala'] ?? $s['no_kk'], ENT_QUOTES) ?>')" title="Hapus"><i class="fas fa-trash"></i></button>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div></section>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
