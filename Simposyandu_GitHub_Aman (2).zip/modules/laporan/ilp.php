<?php
$page_title = 'Laporan ILP Posyandu';
require_once __DIR__ . '/../../includes/header.php';

$s = [
  'balita' => numRows("SELECT id FROM balita WHERE status_aktif=1"),
  'bumil' => numRows("SELECT id FROM ibu_hamil WHERE status_aktif=1"),
  'lansia' => numRows("SELECT id FROM lansia WHERE status_aktif=1"),
  'stunting' => numRows("SELECT pb.id FROM pemeriksaan_balita pb WHERE pb.risiko_stunting='Stunting' AND pb.tanggal_pemeriksaan >= DATE_SUB(NOW(), INTERVAL 3 MONTH)"),
  'gizi' => numRows("SELECT id FROM pemeriksaan_balita WHERE status_gizi IN ('Kurang','Buruk') AND tanggal_pemeriksaan >= DATE_SUB(NOW(), INTERVAL 3 MONTH)"),
  'imunisasi' => numRows("SELECT id FROM imunisasi"),
];
try { $s['bayi'] = numRows("SELECT id FROM bayi WHERE status_aktif=1"); } catch(Throwable $e){ $s['bayi']=0; }
try { $s['remaja'] = numRows("SELECT id FROM remaja WHERE status_aktif=1"); } catch(Throwable $e){ $s['remaja']=0; }
try { $s['up'] = numRows("SELECT id FROM usia_produktif WHERE status_aktif=1"); } catch(Throwable $e){ $s['up']=0; }
try { $s['kunjungan'] = numRows("SELECT id FROM kunjungan_rumah"); } catch(Throwable $e){ $s['kunjungan']=0; }
try { $s['kegiatan'] = numRows("SELECT id FROM kegiatan_posyandu"); } catch(Throwable $e){ $s['kegiatan']=0; }
?>
<section class="content-header"><div class="container-fluid"><div class="row mb-2">
  <div class="col-sm-6"><h1><i class="fas fa-hospital me-2 text-primary"></i>Laporan ILP Posyandu</h1></div>
  <div class="col-sm-6 text-end">
    <button onclick="window.print()" class="btn btn-outline-primary btn-sm"><i class="fas fa-print"></i> Cetak</button>
    <a href="export.php?type=ilp" class="btn btn-outline-success btn-sm"><i class="fas fa-file-excel"></i> Excel</a>
  </div>
</div></div></section>
<section class="content"><div class="container-fluid">
<div class="card"><div class="card-header bg-primary text-white">Ringkasan Integrasi Layanan Primer (ILP)</div>
<div class="card-body">
<div class="row text-center mb-4">
  <div class="col-6 col-md-2 mb-2"><div class="border rounded p-3"><div class="fs-3 fw-bold text-info"><?= $s['bayi'] ?></div><small>Bayi</small></div></div>
  <div class="col-6 col-md-2 mb-2"><div class="border rounded p-3"><div class="fs-3 fw-bold text-success"><?= $s['balita'] ?></div><small>Balita</small></div></div>
  <div class="col-6 col-md-2 mb-2"><div class="border rounded p-3"><div class="fs-3 fw-bold" style="color:#6f42c1"><?= $s['bumil'] ?></div><small>Ibu Hamil</small></div></div>
  <div class="col-6 col-md-2 mb-2"><div class="border rounded p-3"><div class="fs-3 fw-bold text-warning"><?= $s['remaja'] ?></div><small>Remaja</small></div></div>
  <div class="col-6 col-md-2 mb-2"><div class="border rounded p-3"><div class="fs-3 fw-bold text-primary"><?= $s['up'] ?></div><small>Usia Produktif</small></div></div>
  <div class="col-6 col-md-2 mb-2"><div class="border rounded p-3"><div class="fs-3 fw-bold text-secondary"><?= $s['lansia'] ?></div><small>Lansia</small></div></div>
</div>
<table class="table table-bordered">
<tr class="table-light"><th>Indikator</th><th>Jumlah</th><th>Keterangan</th></tr>
<tr><td>Risiko / Kasus Stunting (3 bln terakhir)</td><td><strong class="text-danger"><?= $s['stunting'] ?></strong></td><td>Dari pemeriksaan balita</td></tr>
<tr><td>Gizi Kurang / Buruk (3 bln)</td><td><strong><?= $s['gizi'] ?></strong></td><td>Status gizi pemeriksaan</td></tr>
<tr><td>Data Imunisasi</td><td><?= $s['imunisasi'] ?></td><td>Semua dosis tercatat</td></tr>
<tr><td>Kunjungan Rumah Kader</td><td><?= $s['kunjungan'] ?></td><td>Prioritas ILP</td></tr>
<tr><td>Kegiatan Posyandu tercatat</td><td><?= $s['kegiatan'] ?></td><td>5 langkah</td></tr>
</table>
<p class="text-muted small mb-0">Laporan ini mengikuti kerangka Integrasi Layanan Primer (ILP) Posyandu — Kementerian Kesehatan RI. Data penduduk mengacu OpenSID.</p>
</div></div>
<div class="mt-2"><a href="index.php" class="btn btn-secondary">Kembali</a></div>
</div></section>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
