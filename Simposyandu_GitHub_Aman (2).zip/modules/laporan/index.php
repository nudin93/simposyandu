<?php
$page_title = 'Laporan Terintegrasi';
require_once __DIR__ . '/../../includes/header.php';


try { $stats['bayi'] = numRows("SELECT id FROM bayi WHERE status_aktif=1"); } catch (Throwable $e) {}
try { $stats['kunjungan'] = numRows("SELECT id FROM kunjungan_rumah"); } catch (Throwable $e) {}
try { $stats['kegiatan'] = numRows("SELECT id FROM kegiatan_posyandu"); } catch (Throwable $e) {}

$stats = [
    'balita'     => numRows("SELECT id FROM balita WHERE status_aktif=1"),
    'ibu_hamil'  => numRows("SELECT id FROM ibu_hamil WHERE status_aktif=1"),
    'lansia'     => numRows("SELECT id FROM lansia WHERE status_aktif=1"),
    'stunting'   => numRows("SELECT pb.id FROM pemeriksaan_balita pb WHERE pb.risiko_stunting='Stunting' AND pb.tanggal_pemeriksaan >= DATE_SUB(NOW(), INTERVAL 3 MONTH)"),
    'imunisasi'  => numRows("SELECT id FROM imunisasi"),
    'gizi_kurang'=> numRows("SELECT id FROM pemeriksaan_balita WHERE status_gizi IN ('Kurang','Buruk') AND tanggal_pemeriksaan >= DATE_SUB(NOW(), INTERVAL 3 MONTH)"),
    'jadwal'     => numRows("SELECT id FROM jadwal WHERE status IN ('Terjadwal','Berlangsung')"),
    'kb'         => numRows("SELECT id FROM kb WHERE status='Aktif'"),
    'sanitasi'   => numRows("SELECT id FROM sanitasi"),
    'phbs'       => numRows("SELECT id FROM phbs"),
    'bayi'       => 0,
    'kunjungan'  => 0,
    'kegiatan'   => 0,
    'keluarga'   => numRows("SELECT id FROM keluarga"),
];
?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1><i class="fas fa-file-alt me-2 text-primary"></i>Laporan Terintegrasi</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="<?= APP_URL ?>/dashboard.php">Dashboard</a></li>
          <li class="breadcrumb-item active">Laporan</li>
        </ol>
      </div>
    </div>
  </div>
</section>

<section class="content">
<div class="container-fluid">
<div class="row">
    <!-- Laporan Balita -->
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/laporan/balita.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-info bg-opacity-10 text-info mb-3 mx-auto">
              <i class="fas fa-baby fa-2x"></i>
            </div>
            <h6 class="fw-bold mb-1">Laporan Balita</h6>
            <p class="text-muted small mb-2">Rekap, pertumbuhan, status gizi & stunting</p>
            <span class="badge bg-info"><?= $stats['balita'] ?> aktif</span>
          </div>
        </div>
      </a>
    </div>

    <!-- Laporan Ibu Hamil -->
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/laporan/ibu_hamil.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-purple bg-opacity-10 text-purple mb-3 mx-auto" style="color:#6f42c1">
              <i class="fas fa-female fa-2x"></i>
            </div>
            <h6 class="fw-bold mb-1">Laporan Ibu Hamil</h6>
            <p class="text-muted small mb-2">Pemeriksaan, usia kehamilan & rekap bulanan</p>
            <span class="badge" style="background:#6f42c1"><?= $stats['ibu_hamil'] ?> aktif</span>
          </div>
        </div>
      </a>
    </div>

    
    <!-- Laporan ILP -->
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/laporan/ilp.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-primary bg-opacity-10 text-primary mb-3 mx-auto"><i class="fas fa-hospital fa-2x"></i></div>
            <h6 class="fw-bold mb-1">Laporan ILP Posyandu</h6>
            <p class="text-muted small mb-2">Ringkasan siklus hidup Kemenkes</p>
            <span class="badge bg-primary">ILP</span>
          </div>
        </div>
      </a>
    </div>
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/kunjungan_rumah/index.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-danger bg-opacity-10 text-danger mb-3 mx-auto"><i class="fas fa-house-user fa-2x"></i></div>
            <h6 class="fw-bold mb-1">Laporan Kunjungan Rumah</h6>
            <p class="text-muted small mb-2">Prioritas stunting, bumil Risti, lansia</p>
            <span class="badge bg-danger"><?= $stats['kunjungan'] ?? 0 ?> data</span>
          </div>
        </div>
      </a>
    </div>
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/kegiatan_posyandu/index.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-success bg-opacity-10 text-success mb-3 mx-auto"><i class="fas fa-clipboard-list fa-2x"></i></div>
            <h6 class="fw-bold mb-1">Laporan Kegiatan Posyandu</h6>
            <p class="text-muted small mb-2">5 langkah & kehadiran sasaran</p>
            <span class="badge bg-success"><?= $stats['kegiatan'] ?? 0 ?> kegiatan</span>
          </div>
        </div>
      </a>
    </div>

    <!-- Laporan Lansia -->
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/laporan/lansia.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-primary bg-opacity-10 text-primary mb-3 mx-auto">
              <i class="fas fa-user-injured fa-2x"></i>
            </div>
            <h6 class="fw-bold mb-1">Laporan Lansia</h6>
            <p class="text-muted small mb-2">Riwayat kesehatan, tekanan darah & rekap</p>
            <span class="badge bg-primary"><?= $stats['lansia'] ?> aktif</span>
          </div>
        </div>
      </a>
    </div>

    <!-- Laporan Imunisasi -->
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/laporan/imunisasi.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-success bg-opacity-10 text-success mb-3 mx-auto">
              <i class="fas fa-syringe fa-2x"></i>
            </div>
            <h6 class="fw-bold mb-1">Laporan Imunisasi</h6>
            <p class="text-muted small mb-2">Sudah/belum imunisasi & riwayat</p>
            <span class="badge bg-success"><?= $stats['imunisasi'] ?> data</span>
          </div>
        </div>
      </a>
    </div>

    <!-- Laporan Stunting -->
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/laporan/stunting.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-danger bg-opacity-10 text-danger mb-3 mx-auto">
              <i class="fas fa-exclamation-triangle fa-2x"></i>
            </div>
            <h6 class="fw-bold mb-1">Laporan Stunting</h6>
            <p class="text-muted small mb-2">Jumlah, risiko & grafik perkembangan</p>
            <span class="badge bg-danger"><?= $stats['stunting'] ?> stunting</span>
          </div>
        </div>
      </a>
    </div>

    
    <!-- Laporan KB -->
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/laporan/kb.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-warning bg-opacity-10 text-warning mb-3 mx-auto">
              <i class="fas fa-pills fa-2x"></i>
            </div>
            <h6 class="fw-bold mb-1">Laporan KB</h6>
            <p class="text-muted small mb-2">Peserta & jenis kontrasepsi</p>
            <span class="badge bg-warning text-dark"><?= $stats['kb'] ?> aktif</span>
          </div>
        </div>
      </a>
    </div>

    <!-- Laporan Sanitasi -->
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/laporan/sanitasi.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-success bg-opacity-10 text-success mb-3 mx-auto">
              <i class="fas fa-toilet fa-2x"></i>
            </div>
            <h6 class="fw-bold mb-1">Laporan Sanitasi</h6>
            <p class="text-muted small mb-2">Jamban, air, sampah & rumah</p>
            <span class="badge bg-success"><?= $stats['sanitasi'] ?> data</span>
          </div>
        </div>
      </a>
    </div>

    <!-- Laporan PHBS -->
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/laporan/phbs.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-info bg-opacity-10 text-info mb-3 mx-auto">
              <i class="fas fa-hands-wash fa-2x"></i>
            </div>
            <h6 class="fw-bold mb-1">Laporan PHBS</h6>
            <p class="text-muted small mb-2">Indikator PHBS per keluarga</p>
            <span class="badge bg-info"><?= $stats['phbs'] ?> data</span>
          </div>
        </div>
      </a>
    </div>

    <!-- Laporan Gizi -->

    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/laporan/gizi.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-warning bg-opacity-10 text-warning mb-3 mx-auto">
              <i class="fas fa-chart-pie fa-2x"></i>
            </div>
            <h6 class="fw-bold mb-1">Laporan Gizi</h6>
            <p class="text-muted small mb-2">Status gizi baik, kurang & buruk</p>
            <span class="badge bg-warning text-dark"><?= $stats['gizi_kurang'] ?> kurang/buruk</span>
          </div>
        </div>
      </a>
    </div>

    <!-- Laporan Kegiatan -->
    <div class="col-6 col-md-4 col-lg-3 mb-3">
      <a href="<?= APP_URL ?>/modules/laporan/kegiatan.php" class="text-decoration-none">
        <div class="card h-100 border-0 shadow-sm report-card">
          <div class="card-body text-center">
            <div class="report-icon bg-secondary bg-opacity-10 text-secondary mb-3 mx-auto">
              <i class="fas fa-calendar-check fa-2x"></i>
            </div>
            <h6 class="fw-bold mb-1">Laporan Kegiatan</h6>
            <p class="text-muted small mb-2">Jadwal, peserta & hasil pemeriksaan</p>
            <span class="badge bg-secondary"><?= $stats['jadwal'] ?> aktif</span>
          </div>
        </div>
      </a>
    </div>
  </div>

</div>
</section>

<style>
.report-card { transition: transform .2s, box-shadow .2s; border-radius: 10px; }
.report-card:hover { transform: translateY(-4px); box-shadow: 0 8px 20px rgba(0,0,0,.12) !important; }
.report-icon {
  width: 60px; height: 60px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
}
</style>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
